// Cricket A7 — Types | Asif Lashari | A7 Studio

export type UserRole = 'organizer' | 'captain' | 'scorer' | 'viewer';
export type MatchFormat = 'T20' | 'ODI' | 'T10' | 'Custom';
export type MatchStatus = 'scheduled' | 'toss_pending' | 'openers_pending' | 'live' | 'innings_break' | 'completed' | 'abandoned';
export type InningsStatus = 'pending' | 'ongoing' | 'completed';
export type WicketType = 'bowled' | 'caught' | 'lbw' | 'run-out' | 'stumped' | 'hit-wicket' | 'obstructing' | 'retired-out';
export type ExtraType = 'wide' | 'no-ball' | 'bye' | 'leg-bye' | 'penalty';
export type ShotZone = 'fine-leg' | 'square-leg' | 'midwicket' | 'mid-on' | 'straight' | 'mid-off' | 'covers' | 'point' | 'third-man';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  teamId?: string;
  createdAt: number;
}

export interface Powerplay {
  label: string;    // e.g. "PP1", "PP2"
  fromOver: number;
  toOver: number;
}

export interface Tournament {
  id: string;
  name: string;
  format: MatchFormat;
  totalOvers: number;
  powerplays: Powerplay[];
  hasSuperOver: boolean;
  organizerId: string;
  teamIds: string[];
  matchIds: string[];
  status: 'upcoming' | 'ongoing' | 'completed';
  createdAt: number;
}

export interface Team {
  id: string;
  name: string;
  color: string;
  tournamentId: string | null;   // null = global/standalone team
  captainUserId: string;
  playerIds: string[];
  playingXI: string[];           // exactly 11 playerIds when locked
  isXILocked: boolean;
  createdAt: number;
}

export interface Player {
  id: string;
  name: string;
  teamId: string;
  jerseyNumber: number;
  battingStyle: 'right-hand' | 'left-hand';
  bowlingStyle: 'fast' | 'medium' | 'off-spin' | 'leg-spin' | 'none';
  primaryRole: 'batsman' | 'bowler' | 'allrounder' | 'wicketkeeper';
  assignedRoles: ('captain' | 'vice-captain' | 'wicketkeeper' | 'opener')[];
  battingPosition: number | null;  // 1–11
  createdAt: number;
}

export interface Match {
  id: string;
  tournamentId: string | null;    // null = standalone match
  team1Id: string;
  team2Id: string;
  venue: string;
  scheduledAt: number;
  format: MatchFormat;
  totalOvers: number;
  powerplays: Powerplay[];
  hasSuperOver: boolean;
  status: MatchStatus;
  tossWonBy: string | null;        // teamId
  electedTo: 'bat' | 'bowl' | null;
  scorerToken: string | null;
  scorerUserId: string | null;
  currentInningsIndex: 0 | 1 | null;
  inningsIds: string[];
  isDLS: boolean;
  dlsTarget: number | null;
  result: string | null;
  createdAt: number;
}

export interface Innings {
  id: string;
  matchId: string;
  inningsNumber: 1 | 2;
  battingTeamId: string;
  bowlingTeamId: string;
  totalRuns: number;
  wickets: number;
  legalBalls: number;              // Does NOT count wides/no-balls
  extras: {
    wides: number;
    noBalls: number;
    byes: number;
    legByes: number;
    penalty: number;
  };
  target: number | null;           // Set at start of innings 2
  status: InningsStatus;
  isSuperOver: boolean;
  maxWickets: number;              // 10 normally, 2 for super over
}

export interface Delivery {
  id: string;
  inningsId: string;
  matchId: string;
  overNumber: number;
  ballInOver: number;              // Legal ball count 1–6
  rawSequence: number;             // Includes wides/no-balls for display
  batsmanId: string;
  bowlerId: string;
  nonStrikerId: string;
  runsOffBat: number;
  isLegal: boolean;                // false for wide and no-ball
  extraType: ExtraType | null;
  extraRuns: number;
  isFreeHit: boolean;              // THIS ball is a free hit
  nextIsFreeHit: boolean;          // After a no-ball — next ball is free hit
  isWicket: boolean;
  wicketType: WicketType | null;
  dismissedId: string | null;
  fielderId: string | null;
  isBowlerWicket: boolean;         // false for run-out, obstructing, timed-out
  isBoundary: boolean;
  boundaryType: '4' | '6' | null;
  shotZone: ShotZone | null;
  isPowerplay: boolean;
  timestamp: number;
}

export interface Commentary {
  id: string;
  deliveryId: string | null;
  matchId: string;
  overNumber: number;
  ballInOver: number;
  text: string;
  type: 'normal' | 'wicket' | 'four' | 'six' | 'wide' | 'no-ball' |
        'free-hit' | 'milestone' | 'powerplay-start' | 'powerplay-end' |
        'innings-break' | 'match-result' | 'custom';
  isCustom: boolean;
  addedBy: string;
  timestamp: number;
}

export interface StatsCache {
  id: string;
  playerId: string;
  tournamentId: string;
  matches: number;
  innings: number;
  runs: number;
  balls: number;
  highScore: number;
  notOuts: number;
  average: number;
  strikeRate: number;
  fours: number;
  sixes: number;
  fifties: number;
  hundreds: number;
  inningsBowled: number;
  oversBowled: number;
  runsConceded: number;
  wickets: number;
  economy: number;
  bowlingAvg: number;
  maidens: number;
  updatedAt: number;
}

// Live state for scoring (Zustand store shape)
export interface LiveBatsman {
  playerId: string;
  name: string;
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  isStriker: boolean;
}

export interface LiveBowler {
  playerId: string;
  name: string;
  overs: number;
  legalBalls: number;
  runs: number;
  wickets: number;
  maidens: number;
  wides: number;
  noBalls: number;
}

export interface LiveMatchState {
  matchId: string;
  inningsId: string;
  inningsNumber: 1 | 2;
  battingTeamId: string;
  bowlingTeamId: string;
  totalRuns: number;
  wickets: number;
  legalBalls: number;
  overNumber: number;
  currentOverBalls: Delivery[];
  striker: LiveBatsman | null;
  nonStriker: LiveBatsman | null;
  currentBowler: LiveBowler | null;
  target: number | null;
  isFreeHit: boolean;
  isPowerplay: boolean;
  currentPowerplayLabel: string | null;
  fallOfWickets: { wicketNo: number; runs: number; playerId: string; playerName: string; overText: string }[];
  partnerships: { runs: number; balls: number; batter1Id: string; batter2Id: string }[];
}
