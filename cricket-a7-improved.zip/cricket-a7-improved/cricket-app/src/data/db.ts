// Cricket A7 — Mock Database | Asif Lashari | A7 Studio
import { User, Tournament, Team, Player, Match, Innings, Delivery, Commentary } from '../types';
import { generateScorerToken } from '../logic/scoringEngine';

function uid(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).substr(2, 10)}`;
}

// ─── SEED DATA ────────────────────────────────────────────────────────────────
let _users: User[] = [
  { id: 'usr_organizer1', name: 'Asif Lashari', email: 'organizer@a7.com', role: 'organizer', createdAt: Date.now() },
  { id: 'usr_captain1',   name: 'Ahmed Khan',   email: 'captain@a7.com',   role: 'captain', teamId: 'tem_1', createdAt: Date.now() },
  { id: 'usr_scorer1',    name: 'Bilal Scorer',  email: 'scorer@a7.com',    role: 'scorer',  createdAt: Date.now() },
  { id: 'usr_viewer1',    name: 'Fan User',      email: 'viewer@a7.com',    role: 'viewer',  createdAt: Date.now() },
];

let _tournaments: Tournament[] = [
  {
    id: 'trn_1', name: 'A7 Premier League', format: 'T20', totalOvers: 20,
    powerplays: [{ label: 'PP1', fromOver: 1, toOver: 6 }],
    hasSuperOver: true, organizerId: 'usr_organizer1',
    teamIds: ['tem_1', 'tem_2', 'tem_3', 'tem_4'],
    matchIds: ['mch_1', 'mch_2'],
    status: 'ongoing', createdAt: Date.now() - 86400000,
  },
];

let _teams: Team[] = [
  { id: 'tem_1', name: 'Karachi Kings',  color: '#C9A03E', tournamentId: 'trn_1', captainUserId: 'usr_captain1', playerIds: ['plr_1','plr_2','plr_3','plr_4','plr_5','plr_6','plr_7','plr_8','plr_9','plr_10','plr_11'], playingXI: ['plr_1','plr_2','plr_3','plr_4','plr_5','plr_6','plr_7','plr_8','plr_9','plr_10','plr_11'], isXILocked: true, createdAt: Date.now() },
  { id: 'tem_2', name: 'Lahore Lions',   color: '#00C896', tournamentId: 'trn_1', captainUserId: 'usr_organizer1', playerIds: ['plr_12','plr_13','plr_14','plr_15','plr_16','plr_17','plr_18','plr_19','plr_20','plr_21','plr_22'], playingXI: ['plr_12','plr_13','plr_14','plr_15','plr_16','plr_17','plr_18','plr_19','plr_20','plr_21','plr_22'], isXILocked: true, createdAt: Date.now() },
  { id: 'tem_3', name: 'Peshawar Stars', color: '#8B5CF6', tournamentId: 'trn_1', captainUserId: 'usr_organizer1', playerIds: [], playingXI: [], isXILocked: false, createdAt: Date.now() },
  { id: 'tem_4', name: 'Quetta Force',   color: '#3B82F6', tournamentId: 'trn_1', captainUserId: 'usr_organizer1', playerIds: [], playingXI: [], isXILocked: false, createdAt: Date.now() },
];

const makePlayer = (id: string, name: string, teamId: string, pos: number): Player => ({
  id, name, teamId, jerseyNumber: pos,
  battingStyle: 'right-hand', bowlingStyle: pos > 8 ? 'fast' : 'none',
  primaryRole: pos > 8 ? 'bowler' : pos > 6 ? 'allrounder' : pos === 1 || pos === 2 ? 'batsman' : 'batsman',
  assignedRoles: pos === 1 ? ['captain', 'opener'] : pos === 2 ? ['opener'] : pos === 7 ? ['wicketkeeper'] : [],
  battingPosition: pos, createdAt: Date.now(),
});

let _players: Player[] = [
  makePlayer('plr_1','Asif Nawaz',   'tem_1', 1),
  makePlayer('plr_2','Kamran Ali',   'tem_1', 2),
  makePlayer('plr_3','Usman Tariq',  'tem_1', 3),
  makePlayer('plr_4','Bilal Hassan', 'tem_1', 4),
  makePlayer('plr_5','Zain Khan',    'tem_1', 5),
  makePlayer('plr_6','Hamza Rauf',   'tem_1', 6),
  makePlayer('plr_7','Saeed Baig',   'tem_1', 7),
  makePlayer('plr_8','Tariq Malik',  'tem_1', 8),
  makePlayer('plr_9','Imran Shah',   'tem_1', 9),
  makePlayer('plr_10','Danish Rao',  'tem_1', 10),
  makePlayer('plr_11','Faisal Qureshi','tem_1',11),
  makePlayer('plr_12','Rizwan Ahmed','tem_2', 1),
  makePlayer('plr_13','Shoaib Akhtar','tem_2',2),
  makePlayer('plr_14','Wahab Riaz',  'tem_2', 3),
  makePlayer('plr_15','Shahid Afridi','tem_2',4),
  makePlayer('plr_16','Younis Khan', 'tem_2', 5),
  makePlayer('plr_17','Misbah Ul Haq','tem_2',6),
  makePlayer('plr_18','Sarfraz Ahmed','tem_2',7),
  makePlayer('plr_19','Amir Sohail', 'tem_2', 8),
  makePlayer('plr_20','Waqar Younis','tem_2', 9),
  makePlayer('plr_21','Mushtaq Ahmed','tem_2',10),
  makePlayer('plr_22','Saqlain Mushtaq','tem_2',11),
];

let _matches: Match[] = [
  {
    id: 'mch_1', tournamentId: 'trn_1', team1Id: 'tem_1', team2Id: 'tem_2',
    venue: 'National Stadium, Karachi', scheduledAt: Date.now() + 3600000,
    format: 'T20', totalOvers: 20,
    powerplays: [{ label: 'PP1', fromOver: 1, toOver: 6 }],
    hasSuperOver: true, status: 'scheduled',
    tossWonBy: null, electedTo: null,
    scorerToken: null, scorerUserId: null,
    currentInningsIndex: null, inningsIds: [],
    isDLS: false, dlsTarget: null, result: null,
    createdAt: Date.now(),
  },
  {
    id: 'mch_2', tournamentId: 'trn_1', team1Id: 'tem_3', team2Id: 'tem_4',
    venue: 'Gaddafi Stadium, Lahore', scheduledAt: Date.now() + 86400000,
    format: 'T20', totalOvers: 20,
    powerplays: [{ label: 'PP1', fromOver: 1, toOver: 6 }],
    hasSuperOver: true, status: 'scheduled',
    tossWonBy: null, electedTo: null,
    scorerToken: null, scorerUserId: null,
    currentInningsIndex: null, inningsIds: [],
    isDLS: false, dlsTarget: null, result: null,
    createdAt: Date.now(),
  },
];

let _innings: Innings[] = [];
let _deliveries: Delivery[] = [];
let _commentary: Commentary[] = [];
let _currentUser: User | null = _users[0];

// ─── DB INTERFACE ─────────────────────────────────────────────────────────────
export const db = {

  auth: {
    getCurrentUser: () => _currentUser,
    login: (email: string): User | null => {
      const u = _users.find(u => u.email === email);
      if (u) _currentUser = u;
      return u || null;
    },
    logout: () => { _currentUser = null; },
    register: (data: Omit<User, 'id' | 'createdAt'>): User => {
      const u: User = { ...data, id: uid('usr'), createdAt: Date.now() };
      _users.push(u);
      _currentUser = u;
      return u;
    },
  },

  tournaments: {
    getAll: () => [..._tournaments],
    getById: (id: string) => _tournaments.find(t => t.id === id) || null,
    getByOrganizer: (orgId: string) => _tournaments.filter(t => t.organizerId === orgId),
    create: (data: Omit<Tournament, 'id' | 'createdAt' | 'teamIds' | 'matchIds'>): Tournament => {
      const t: Tournament = { ...data, id: uid('trn'), teamIds: [], matchIds: [], createdAt: Date.now() };
      _tournaments.push(t);
      return t;
    },
    update: (id: string, data: Partial<Tournament>) => {
      const i = _tournaments.findIndex(t => t.id === id);
      if (i >= 0) _tournaments[i] = { ..._tournaments[i], ...data };
      return _tournaments.find(t => t.id === id) || null;
    },
    delete: (id: string) => { _tournaments = _tournaments.filter(t => t.id !== id); },
  },

  teams: {
    getAll: () => [..._teams],
    getById: (id: string) => _teams.find(t => t.id === id) || null,
    getByTournament: (trnId: string) => _teams.filter(t => t.tournamentId === trnId),
    create: (data: Omit<Team, 'id' | 'createdAt'>): Team => {
      const t: Team = { ...data, id: uid('tem'), createdAt: Date.now() };
      _teams.push(t);
      return t;
    },
    update: (id: string, data: Partial<Team>) => {
      const i = _teams.findIndex(t => t.id === id);
      if (i >= 0) _teams[i] = { ..._teams[i], ...data };
      return _teams.find(t => t.id === id) || null;
    },
    delete: (id: string) => { _teams = _teams.filter(t => t.id !== id); },
  },

  players: {
    getAll: () => [..._players],
    getById: (id: string) => _players.find(p => p.id === id) || null,
    getByTeam: (teamId: string) => _players.filter(p => p.teamId === teamId).sort((a,b) => (a.battingPosition||99)-(b.battingPosition||99)),
    create: (data: Omit<Player, 'id' | 'createdAt'>): Player => {
      const p: Player = { ...data, id: uid('plr'), createdAt: Date.now() };
      _players.push(p);
      return p;
    },
    update: (id: string, data: Partial<Player>) => {
      const i = _players.findIndex(p => p.id === id);
      if (i >= 0) _players[i] = { ..._players[i], ...data };
      return _players.find(p => p.id === id) || null;
    },
    delete: (id: string) => { _players = _players.filter(p => p.id !== id); },
  },

  matches: {
    getAll: () => [..._matches],
    getById: (id: string) => _matches.find(m => m.id === id) || null,
    getLive: () => _matches.filter(m => m.status === 'live'),
    getByTournament: (trnId: string) => _matches.filter(m => m.tournamentId === trnId),
    getStandalone: () => _matches.filter(m => !m.tournamentId),
    create: (data: Omit<Match, 'id' | 'createdAt'>): Match => {
      const m: Match = { ...data, id: uid('mch'), createdAt: Date.now() };
      _matches.push(m);
      // Link to tournament if provided
      if (data.tournamentId) {
        const trn = _tournaments.find(t => t.id === data.tournamentId);
        if (trn) trn.matchIds = [...trn.matchIds, m.id];
      }
      return m;
    },
    update: (id: string, data: Partial<Match>) => {
      const i = _matches.findIndex(m => m.id === id);
      if (i >= 0) _matches[i] = { ..._matches[i], ...data };
      return _matches.find(m => m.id === id) || null;
    },
    generateToken: (matchId: string): string => {
      const token = generateScorerToken();
      const i = _matches.findIndex(m => m.id === matchId);
      if (i >= 0) _matches[i].scorerToken = token;
      return token;
    },
    validateToken: (token: string, matchId: string): boolean => {
      const match = _matches.find(m => m.id === matchId);
      return match?.scorerToken === token.toUpperCase();
    },
    activateScorer: (matchId: string, scorerUserId: string) => {
      const i = _matches.findIndex(m => m.id === matchId);
      if (i >= 0) {
        _matches[i].scorerUserId = scorerUserId;
        _matches[i].status = 'toss_pending';
      }
    },
  },

  innings: {
    getAll: () => [..._innings],
    getById: (id: string) => _innings.find(i => i.id === id) || null,
    getByMatch: (matchId: string) => _innings.filter(i => i.matchId === matchId),
    create: (data: Omit<Innings, 'id'>): Innings => {
      const inn: Innings = { ...data, id: uid('inn') };
      _innings.push(inn);
      const match = _matches.find(m => m.id === data.matchId);
      if (match) match.inningsIds = [...match.inningsIds, inn.id];
      return inn;
    },
    update: (id: string, data: Partial<Innings>) => {
      const i = _innings.findIndex(inn => inn.id === id);
      if (i >= 0) _innings[i] = { ..._innings[i], ...data };
      return _innings.find(inn => inn.id === id) || null;
    },
  },

  deliveries: {
    getByInnings: (inningsId: string) => _deliveries.filter(d => d.inningsId === inningsId),
    getByMatch: (matchId: string) => _deliveries.filter(d => d.matchId === matchId),
    add: (data: Omit<Delivery, 'id'>): Delivery => {
      const d: Delivery = { ...data, id: uid('dlv') };
      _deliveries.push(d);
      return d;
    },
    // Undo last delivery of an innings
    undoLast: (inningsId: string): Delivery | null => {
      const idx = _deliveries.map(d => d.inningsId).lastIndexOf(inningsId);
      if (idx < 0) return null;
      const removed = _deliveries[idx];
      _deliveries.splice(idx, 1);
      return removed;
    },
  },

  commentary: {
    getByMatch: (matchId: string) => _commentary.filter(c => c.matchId === matchId).sort((a,b) => b.timestamp - a.timestamp),
    add: (data: Omit<Commentary, 'id'>): Commentary => {
      const c: Commentary = { ...data, id: uid('com') };
      _commentary.push(c);
      return c;
    },
  },
};
