// Cricket A7 — Fixture Screen | Grouped by tournament + standalone | Asif Lashari | A7 Studio
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, SectionList, TouchableOpacity, StatusBar,
} from 'react-native';
import { theme } from '../../theme';
import { db } from '../../data/db';
import { Match } from '../../types';

const T = theme;
interface Props { onBack: () => void; onNavigate: (s: string, p?: any) => void; }

type Filter = 'all' | 'scheduled' | 'live' | 'completed';

const STATUS_COLOR: Record<string, string> = {
  scheduled: T.colors.status.upcoming,
  toss_pending: T.colors.orange,
  openers_pending: T.colors.orange,
  live: T.colors.status.live,
  innings_break: T.colors.orange,
  completed: T.colors.status.completed,
  abandoned: T.colors.status.abandoned,
};

const formatTs = (ts: number) => new Date(ts).toLocaleDateString('en-PK', { day:'numeric', month:'short' });
const formatTime = (ts: number) => new Date(ts).toLocaleTimeString('en-PK', { hour:'2-digit', minute:'2-digit' });

export const FixtureScreen: React.FC<Props> = ({ onBack, onNavigate }) => {
  const [filter, setFilter] = useState<Filter>('all');

  const allMatches = db.matches.getAll();
  const tournaments = db.tournaments.getAll();

  const filtered = filter === 'all'
    ? allMatches
    : filter === 'live'
    ? allMatches.filter(m => ['live','toss_pending','openers_pending','innings_break'].includes(m.status))
    : allMatches.filter(m => m.status === filter);

  // Group: tournament sections + standalone
  const grouped: { title: string; data: Match[]; color?: string }[] = [];

  tournaments.forEach(trn => {
    const trnMatches = filtered.filter(m => m.tournamentId === trn.id);
    if (trnMatches.length > 0) {
      grouped.push({ title: trn.name, data: trnMatches, color: T.colors.gold });
    }
  });

  const standalone = filtered.filter(m => !m.tournamentId);
  if (standalone.length > 0) {
    grouped.push({ title: 'Standalone Matches', data: standalone, color: T.colors.blue });
  }

  const counts = {
    all: allMatches.length,
    scheduled: allMatches.filter(m => m.status === 'scheduled').length,
    live: allMatches.filter(m => ['live','toss_pending','openers_pending','innings_break'].includes(m.status)).length,
    completed: allMatches.filter(m => m.status === 'completed').length,
  };

  return (
    <View style={s.screen}>
      <StatusBar barStyle="light-content" />

      <View style={s.header}>
        <TouchableOpacity onPress={onBack} style={s.backBtn}>
          <Text style={s.backText}>‹</Text>
        </TouchableOpacity>
        <View style={s.headerCenter}>
          <Text style={s.headerTitle}>Fixtures</Text>
          <Text style={s.headerSub}>{allMatches.length} total matches</Text>
        </View>
        <TouchableOpacity style={s.addBtn} onPress={() => onNavigate('MatchSetup')}>
          <Text style={s.addBtnText}>+ Match</Text>
        </TouchableOpacity>
      </View>

      {/* Filter tabs */}
      <View style={s.filterRow}>
        {(['all','scheduled','live','completed'] as Filter[]).map(f => (
          <TouchableOpacity
            key={f}
            style={[s.filterTab, filter === f && s.filterTabActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[s.filterText, filter === f && s.filterTextActive]}>
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </Text>
            {counts[f] > 0 && (
              <View style={[s.filterCount, filter === f && s.filterCountActive]}>
                <Text style={[s.filterCountText, filter === f && s.filterCountTextActive]}>{counts[f]}</Text>
              </View>
            )}
          </TouchableOpacity>
        ))}
      </View>

      <SectionList
        sections={grouped}
        keyExtractor={m => m.id}
        contentContainerStyle={s.list}
        showsVerticalScrollIndicator={false}
        renderSectionHeader={({ section }) => (
          <View style={s.sectionHeader}>
            <View style={[s.sectionDot, { backgroundColor: section.color || T.colors.gold }]} />
            <Text style={s.sectionTitle}>{section.title}</Text>
            <Text style={s.sectionCount}>{section.data.length} match{section.data.length !== 1 ? 'es' : ''}</Text>
          </View>
        )}
        renderItem={({ item: m }) => <MatchCard match={m} onPress={() => onNavigate('MatchDetail', { matchId: m.id })} onTokenPress={() => onNavigate('TokenGenerate', { matchId: m.id })} />}
        ListEmptyComponent={
          <View style={s.empty}>
            <Text style={s.emptyIcon}>📅</Text>
            <Text style={s.emptyTitle}>No matches found</Text>
            <Text style={s.emptySub}>Adjust the filter or create a new match.</Text>
            <TouchableOpacity style={s.emptyBtn} onPress={() => onNavigate('MatchSetup')}>
              <Text style={s.emptyBtnText}>Create Match</Text>
            </TouchableOpacity>
          </View>
        }
      />
    </View>
  );
};

const MatchCard = ({ match, onPress, onTokenPress }: { match: Match; onPress: () => void; onTokenPress: () => void }) => {
  const t1 = db.teams.getById(match.team1Id);
  const t2 = db.teams.getById(match.team2Id);
  const innings = db.innings.getByMatch(match.id);
  const inn1 = innings[0];
  const inn2 = innings[1];
  const statusColor = STATUS_COLOR[match.status] || T.colors.textMuted;
  const isLive = ['live', 'toss_pending', 'openers_pending', 'innings_break'].includes(match.status);
  const needsToken = match.status === 'scheduled' && !match.scorerToken;

  return (
    <TouchableOpacity style={[s.card, isLive && s.cardLive]} onPress={onPress} activeOpacity={0.8}>
      {/* Status + date row */}
      <View style={s.cardHeader}>
        <View style={[s.statusBadge, { backgroundColor: statusColor + '22' }]}>
          {isLive && <View style={s.statusDot} />}
          <Text style={[s.statusText, { color: statusColor }]}>
            {match.status === 'live' ? 'LIVE' : match.status.replace('_', ' ').toUpperCase()}
          </Text>
        </View>
        <Text style={s.matchDate}>{formatTs(match.scheduledAt)} · {formatTime(match.scheduledAt)}</Text>
        <Text style={s.matchFormat}>{match.format} · {match.totalOvers}ov</Text>
      </View>

      {/* Teams row */}
      <View style={s.teamsRow}>
        {/* Team 1 */}
        <View style={s.teamSide}>
          <View style={[s.teamColorBar, { backgroundColor: t1?.color || T.colors.gold }]} />
          <View>
            <Text style={s.teamName}>{t1?.name || 'TBC'}</Text>
            {inn1 ? (
              <Text style={s.teamScore}>
                {inn1.totalRuns}/{inn1.wickets} ({Math.floor(inn1.legalBalls/6)}.{inn1.legalBalls%6} ov)
              </Text>
            ) : (
              <Text style={s.teamScorePending}>—</Text>
            )}
          </View>
        </View>

        <Text style={s.vsLabel}>VS</Text>

        {/* Team 2 */}
        <View style={[s.teamSide, s.teamSideRight]}>
          <View>
            <Text style={[s.teamName, { textAlign: 'right' }]}>{t2?.name || 'TBC'}</Text>
            {inn2 ? (
              <Text style={[s.teamScore, { textAlign: 'right' }]}>
                {inn2.totalRuns}/{inn2.wickets} ({Math.floor(inn2.legalBalls/6)}.{inn2.legalBalls%6} ov)
              </Text>
            ) : (
              <Text style={[s.teamScorePending, { textAlign: 'right' }]}>—</Text>
            )}
          </View>
          <View style={[s.teamColorBar, { backgroundColor: t2?.color || T.colors.emerald }]} />
        </View>
      </View>

      {/* Result */}
      {match.result && (
        <Text style={s.resultText}>{match.result}</Text>
      )}

      {/* Venue + token */}
      <View style={s.cardFooter}>
        <Text style={s.venue} numberOfLines={1}>📍 {match.venue}</Text>
        {needsToken && (
          <TouchableOpacity style={s.tokenBtn} onPress={onTokenPress}>
            <Text style={s.tokenBtnText}>+ Token</Text>
          </TouchableOpacity>
        )}
        {match.scorerToken && match.status === 'scheduled' && (
          <View style={s.tokenReady}>
            <Text style={s.tokenReadyText}>🔑 Token Ready</Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
};

const s = StyleSheet.create({
  screen:           { flex: 1, backgroundColor: T.colors.bg },
  header:           { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: T.colors.border },
  backBtn:          { width: 40 },
  backText:         { fontSize: 22, color: T.colors.gold, fontWeight: '600' },
  headerCenter:     { flex: 1 },
  headerTitle:      { fontSize: 20, fontWeight: '800', color: T.colors.text },
  headerSub:        { fontSize: 11, color: T.colors.textMuted, marginTop: 2 },
  addBtn:           { backgroundColor: T.colors.goldBg, paddingHorizontal: 12, paddingVertical: 7, borderRadius: T.radius.md, borderWidth: 1, borderColor: T.colors.border },
  addBtnText:       { fontSize: 12, fontWeight: '700', color: T.colors.gold },
  filterRow:        { flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 12, gap: 8, borderBottomWidth: 1, borderBottomColor: T.colors.borderLight },
  filterTab:        { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 12, paddingVertical: 7, borderRadius: T.radius.full, borderWidth: 1, borderColor: T.colors.border, backgroundColor: T.colors.bgCard },
  filterTabActive:  { borderColor: T.colors.gold, backgroundColor: T.colors.goldBg },
  filterText:       { fontSize: 12, fontWeight: '600', color: T.colors.textMuted },
  filterTextActive: { color: T.colors.goldLight },
  filterCount:      { backgroundColor: T.colors.bgElevated, borderRadius: T.radius.full, paddingHorizontal: 6, paddingVertical: 1 },
  filterCountActive:{ backgroundColor: T.colors.gold + '33' },
  filterCountText:  { fontSize: 10, color: T.colors.textMuted, fontWeight: '700' },
  filterCountTextActive: { color: T.colors.gold },
  list:             { paddingBottom: 40 },
  sectionHeader:    { flexDirection: 'row', alignItems: 'center', gap: 8, paddingHorizontal: 16, paddingTop: 20, paddingBottom: 10 },
  sectionDot:       { width: 8, height: 8, borderRadius: 4 },
  sectionTitle:     { fontSize: 12, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 1.5, flex: 1 },
  sectionCount:     { fontSize: 11, color: T.colors.textMuted },
  card:             { marginHorizontal: 16, marginBottom: 10, backgroundColor: T.colors.bgCard, borderRadius: T.radius.lg, padding: 14, borderWidth: 1, borderColor: T.colors.border, ...T.shadow.sm },
  cardLive:         { borderColor: T.colors.red + '44', backgroundColor: T.colors.redBg },
  cardHeader:       { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  statusBadge:      { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 3, borderRadius: T.radius.full },
  statusDot:        { width: 5, height: 5, borderRadius: 3, backgroundColor: T.colors.red },
  statusText:       { fontSize: 9, fontWeight: '800', letterSpacing: 1 },
  matchDate:        { fontSize: 11, color: T.colors.textMuted, flex: 1, textAlign: 'center' },
  matchFormat:      { fontSize: 10, color: T.colors.textMuted },
  teamsRow:         { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  teamSide:         { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
  teamSideRight:    { justifyContent: 'flex-end' },
  teamColorBar:     { width: 3, height: 36, borderRadius: 2 },
  teamName:         { fontSize: 14, fontWeight: '700', color: T.colors.text },
  teamScore:        { fontSize: 13, fontWeight: '800', color: T.colors.goldLight, marginTop: 2 },
  teamScorePending: { fontSize: 13, color: T.colors.textMuted, marginTop: 2 },
  vsLabel:          { fontSize: 11, fontWeight: '700', color: T.colors.textMuted, paddingHorizontal: 10, backgroundColor: T.colors.bgElevated, borderRadius: T.radius.sm, paddingVertical: 4 },
  resultText:       { fontSize: 12, color: T.colors.emerald, fontWeight: '600', textAlign: 'center', paddingVertical: 6, borderTopWidth: 1, borderTopColor: T.colors.borderLight },
  cardFooter:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 10, borderTopWidth: 1, borderTopColor: T.colors.borderLight },
  venue:            { fontSize: 11, color: T.colors.textMuted, flex: 1 },
  tokenBtn:         { paddingHorizontal: 10, paddingVertical: 5, backgroundColor: T.colors.orangeBg, borderRadius: T.radius.full, borderWidth: 1, borderColor: T.colors.orange + '44' },
  tokenBtnText:     { fontSize: 10, fontWeight: '700', color: T.colors.orange },
  tokenReady:       { paddingHorizontal: 8, paddingVertical: 3, backgroundColor: T.colors.emeraldBg, borderRadius: T.radius.full },
  tokenReadyText:   { fontSize: 10, fontWeight: '600', color: T.colors.emerald },
  empty:            { alignItems: 'center', padding: 60 },
  emptyIcon:        { fontSize: 48, marginBottom: 12 },
  emptyTitle:       { fontSize: 18, fontWeight: '800', color: T.colors.text, marginBottom: 6 },
  emptySub:         { fontSize: 12, color: T.colors.textMuted, textAlign: 'center', marginBottom: 20 },
  emptyBtn:         { backgroundColor: T.colors.goldBg, paddingHorizontal: 20, paddingVertical: 10, borderRadius: T.radius.lg, borderWidth: 1, borderColor: T.colors.border },
  emptyBtnText:     { fontSize: 13, fontWeight: '700', color: T.colors.gold },
});
