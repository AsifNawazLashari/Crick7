// Cricket A7 — Match Setup Screen | Fixed Logic | Asif Lashari | A7 Studio
// FIXES:
//   - Toss moved OUT of match creation (done after scorer activates)
//   - Standalone match support (tournamentId = null)
//   - Format presets auto-fill overs + powerplays
//   - Playing XI validation BEFORE allowing match save
//   - Date/time picker with proper scheduling
//   - Token is NOT generated here — separate screen
import React, { useState, useMemo } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Alert, StatusBar, Platform,
} from 'react-native';
import { theme } from '../../theme';
import { db } from '../../data/db';
import { MatchFormat, Powerplay } from '../../types';

const T = theme;

interface Props { onBack: () => void; onNavigate: (s: string, p?: any) => void; }

type Step = 'type' | 'teams' | 'config' | 'review';

const FORMAT_PRESETS: Record<MatchFormat, { overs: number; powerplays: Powerplay[]; superOver: boolean }> = {
  T20:    { overs: 20, powerplays: [{ label: 'PP1', fromOver: 1, toOver: 6 }], superOver: true },
  ODI:    { overs: 50, powerplays: [{ label: 'PP1', fromOver: 1, toOver: 10 }, { label: 'PP2', fromOver: 11, toOver: 40 }, { label: 'PP3', fromOver: 41, toOver: 50 }], superOver: true },
  T10:    { overs: 10, powerplays: [{ label: 'PP1', fromOver: 1, toOver: 4 }],  superOver: true },
  Custom: { overs: 20, powerplays: [],                                           superOver: false },
};

export const MatchSetupScreen: React.FC<Props> = ({ onBack, onNavigate }) => {
  const [step, setStep]           = useState<Step>('type');
  const [isStandalone, setStandalone] = useState(false);
  const [tournamentId, setTournamentId] = useState('');
  const [team1Id, setTeam1Id]     = useState('');
  const [team2Id, setTeam2Id]     = useState('');
  const [venue, setVenue]         = useState('');
  const [format, setFormat]       = useState<MatchFormat>('T20');
  const [totalOvers, setTotalOvers] = useState(20);
  const [powerplays, setPowerplays] = useState<Powerplay[]>(FORMAT_PRESETS.T20.powerplays);
  const [hasSuperOver, setSuperOver] = useState(true);
  const [scheduledDate, setScheduledDate] = useState(new Date());
  const [loading, setLoading]     = useState(false);

  const tournaments = db.tournaments.getAll();
  const allTeams    = db.teams.getAll();
  const teams       = isStandalone
    ? allTeams
    : allTeams.filter(t => t.tournamentId === tournamentId || !t.tournamentId);

  const team1 = team1Id ? db.teams.getById(team1Id) : null;
  const team2 = team2Id ? db.teams.getById(team2Id) : null;

  // XI readiness check
  const team1XIReady = team1 ? team1.playingXI.length === 11 && team1.isXILocked : false;
  const team2XIReady = team2 ? team2.playingXI.length === 11 && team2.isXILocked : false;

  const applyFormat = (f: MatchFormat) => {
    setFormat(f);
    const p = FORMAT_PRESETS[f];
    setTotalOvers(p.overs);
    setPowerplays(p.powerplays);
    setSuperOver(p.superOver);
  };

  const canProceedTeams = team1Id && team2Id && team1Id !== team2Id && venue.trim().length > 0;
  const canCreate = canProceedTeams && team1XIReady && team2XIReady;

  const handleCreate = async () => {
    if (!canCreate) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 400));

    const match = db.matches.create({
      tournamentId: isStandalone ? null : (tournamentId || null),
      team1Id, team2Id, venue: venue.trim(),
      scheduledAt: scheduledDate.getTime(),
      format, totalOvers, powerplays, hasSuperOver,
      status: 'scheduled',
      tossWonBy: null, electedTo: null,
      scorerToken: null, scorerUserId: null,
      currentInningsIndex: null, inningsIds: [],
      isDLS: false, dlsTarget: null, result: null,
    });

    setLoading(false);
    Alert.alert(
      'Match Created!',
      `${team1?.name} vs ${team2?.name} has been scheduled.\n\nGenerate a scorer token when ready.`,
      [
        { text: 'Generate Token Now', onPress: () => onNavigate('TokenGenerate', { matchId: match.id }) },
        { text: 'View Fixtures', onPress: () => onNavigate('Fixture') },
        { text: 'OK' },
      ]
    );
    onBack();
  };

  const stepIndicator = (['type','teams','config','review'] as Step[]).indexOf(step);

  return (
    <View style={s.screen}>
      <StatusBar barStyle="light-content" />

      {/* Header */}
      <View style={s.header}>
        <TouchableOpacity onPress={onBack} style={s.backBtn}>
          <Text style={s.backText}>‹ Back</Text>
        </TouchableOpacity>
        <View style={s.headerCenter}>
          <Text style={s.headerTitle}>New Match</Text>
          <Text style={s.headerSub}>Step {stepIndicator + 1} of 4</Text>
        </View>
        <View style={{ width: 60 }} />
      </View>

      {/* Step dots */}
      <View style={s.stepRow}>
        {(['type','teams','config','review'] as Step[]).map((st, i) => (
          <View key={st} style={[s.stepDot, step === st && s.stepDotActive, i < stepIndicator && s.stepDotDone]} />
        ))}
      </View>

      <ScrollView style={s.scroll} contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">

        {/* ── STEP 1: Match Type ── */}
        {step === 'type' && (
          <View>
            <Text style={s.stepTitle}>Match Type</Text>
            <Text style={s.stepDesc}>Is this part of a tournament or a one-off match?</Text>

            <TouchableOpacity
              style={[s.typeCard, !isStandalone && s.typeCardActive]}
              onPress={() => setStandalone(false)}
            >
              <Text style={s.typeIcon}>🏆</Text>
              <View style={s.typeInfo}>
                <Text style={[s.typeLabel, !isStandalone && s.typeLabelActive]}>Tournament Match</Text>
                <Text style={s.typeDesc}>Part of an existing tournament</Text>
              </View>
              {!isStandalone && <Text style={s.checkMark}>✓</Text>}
            </TouchableOpacity>

            <TouchableOpacity
              style={[s.typeCard, isStandalone && s.typeCardActive]}
              onPress={() => setStandalone(true)}
            >
              <Text style={s.typeIcon}>⚔️</Text>
              <View style={s.typeInfo}>
                <Text style={[s.typeLabel, isStandalone && s.typeLabelActive]}>Standalone Match</Text>
                <Text style={s.typeDesc}>Friendly / exhibition / one-off</Text>
              </View>
              {isStandalone && <Text style={s.checkMark}>✓</Text>}
            </TouchableOpacity>

            {!isStandalone && (
              <>
                <Text style={s.fieldLabel}>Select Tournament</Text>
                {tournaments.length === 0 ? (
                  <View style={s.warnBox}>
                    <Text style={s.warnText}>No tournaments yet.</Text>
                    <TouchableOpacity onPress={() => onNavigate('TournamentCreate')} style={s.warnBtn}>
                      <Text style={s.warnBtnText}>Create Tournament</Text>
                    </TouchableOpacity>
                  </View>
                ) : (
                  tournaments.map(t => (
                    <TouchableOpacity
                      key={t.id}
                      style={[s.optionRow, tournamentId === t.id && s.optionActive]}
                      onPress={() => setTournamentId(t.id)}
                    >
                      <Text style={[s.optionText, tournamentId === t.id && s.optionTextActive]}>{t.name}</Text>
                      <Text style={s.optionMeta}>{t.format} · {t.totalOvers}ov</Text>
                    </TouchableOpacity>
                  ))
                )}
              </>
            )}

            <TouchableOpacity
              style={[s.nextBtn, (!isStandalone && !tournamentId) && s.nextBtnDisabled]}
              onPress={() => (isStandalone || tournamentId) && setStep('teams')}
              disabled={!isStandalone && !tournamentId}
            >
              <Text style={s.nextBtnText}>Continue to Teams ›</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* ── STEP 2: Teams + Venue ── */}
        {step === 'teams' && (
          <View>
            <Text style={s.stepTitle}>Select Teams & Venue</Text>
            <Text style={s.stepDesc}>Choose the two teams and match venue.</Text>

            <Text style={s.fieldLabel}>Team 1</Text>
            <View style={s.teamGrid}>
              {teams.map(t => (
                <TouchableOpacity
                  key={t.id}
                  style={[s.teamChip, team1Id === t.id && s.teamChipActive, t.id === team2Id && s.teamChipDisabled]}
                  onPress={() => t.id !== team2Id && setTeam1Id(t.id === team1Id ? '' : t.id)}
                >
                  <View style={[s.teamColorDot, { backgroundColor: t.color }]} />
                  <Text style={[s.teamChipText, team1Id === t.id && s.teamChipTextActive]}>{t.name}</Text>
                  {t.id === team1Id && <Text style={s.teamChipCheck}>✓</Text>}
                </TouchableOpacity>
              ))}
            </View>

            <Text style={s.fieldLabel}>Team 2</Text>
            <View style={s.teamGrid}>
              {teams.filter(t => t.id !== team1Id).map(t => (
                <TouchableOpacity
                  key={t.id}
                  style={[s.teamChip, team2Id === t.id && s.teamChipActive]}
                  onPress={() => setTeam2Id(t.id === team2Id ? '' : t.id)}
                >
                  <View style={[s.teamColorDot, { backgroundColor: t.color }]} />
                  <Text style={[s.teamChipText, team2Id === t.id && s.teamChipTextActive]}>{t.name}</Text>
                  {t.id === team2Id && <Text style={s.teamChipCheck}>✓</Text>}
                </TouchableOpacity>
              ))}
            </View>

            {/* XI readiness indicators */}
            {team1Id && (
              <View style={[s.xiAlert, team1XIReady ? s.xiAlertOk : s.xiAlertWarn]}>
                <Text style={s.xiAlertText}>
                  {team1?.name}: {team1XIReady ? '✓ Playing XI locked (11 players)' : `⚠ Playing XI not ready (${team1?.playingXI.length || 0}/11)`}
                </Text>
                {!team1XIReady && (
                  <TouchableOpacity onPress={() => onNavigate('TeamManage', { teamId: team1Id })}>
                    <Text style={s.xiFixBtn}>Fix ›</Text>
                  </TouchableOpacity>
                )}
              </View>
            )}
            {team2Id && (
              <View style={[s.xiAlert, team2XIReady ? s.xiAlertOk : s.xiAlertWarn]}>
                <Text style={s.xiAlertText}>
                  {team2?.name}: {team2XIReady ? '✓ Playing XI locked (11 players)' : `⚠ Playing XI not ready (${team2?.playingXI.length || 0}/11)`}
                </Text>
                {!team2XIReady && (
                  <TouchableOpacity onPress={() => onNavigate('TeamManage', { teamId: team2Id })}>
                    <Text style={s.xiFixBtn}>Fix ›</Text>
                  </TouchableOpacity>
                )}
              </View>
            )}

            <Text style={s.fieldLabel}>Venue</Text>
            <TextInput
              style={s.textInput}
              value={venue}
              onChangeText={setVenue}
              placeholder="e.g. National Stadium, Karachi"
              placeholderTextColor={T.colors.textMuted}
            />

            <View style={s.navRow}>
              <TouchableOpacity style={s.backStepBtn} onPress={() => setStep('type')}>
                <Text style={s.backStepText}>‹ Back</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[s.nextBtn, !canProceedTeams && s.nextBtnDisabled]}
                onPress={() => canProceedTeams && setStep('config')}
                disabled={!canProceedTeams}
              >
                <Text style={s.nextBtnText}>Continue ›</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* ── STEP 3: Format Config ── */}
        {step === 'config' && (
          <View>
            <Text style={s.stepTitle}>Match Configuration</Text>
            <Text style={s.stepDesc}>Set format, overs and powerplay rules.</Text>

            <Text style={s.fieldLabel}>Format Preset</Text>
            <View style={s.formatGrid}>
              {(Object.keys(FORMAT_PRESETS) as MatchFormat[]).map(f => (
                <TouchableOpacity
                  key={f}
                  style={[s.formatBtn, format === f && s.formatBtnActive]}
                  onPress={() => applyFormat(f)}
                >
                  <Text style={[s.formatBtnLabel, format === f && s.formatBtnLabelActive]}>{f}</Text>
                  <Text style={s.formatBtnSub}>{FORMAT_PRESETS[f].overs} ov</Text>
                </TouchableOpacity>
              ))}
            </View>

            <Text style={s.fieldLabel}>Total Overs</Text>
            <TextInput
              style={s.textInput}
              value={String(totalOvers)}
              onChangeText={v => setTotalOvers(Number(v) || 20)}
              keyboardType="numeric"
              placeholderTextColor={T.colors.textMuted}
            />

            <Text style={s.fieldLabel}>Powerplays</Text>
            {powerplays.map((pp, i) => (
              <View key={i} style={s.ppRow}>
                <Text style={s.ppLabel}>{pp.label}</Text>
                <Text style={s.ppRange}>Overs {pp.fromOver}–{pp.toOver}</Text>
              </View>
            ))}
            {powerplays.length === 0 && <Text style={s.noData}>No powerplays configured</Text>}

            <View style={s.toggleRow}>
              <Text style={s.toggleLabel}>Super Over on Tie</Text>
              <TouchableOpacity style={[s.toggle, hasSuperOver && s.toggleOn]} onPress={() => setSuperOver(!hasSuperOver)}>
                <View style={[s.toggleThumb, hasSuperOver && s.toggleThumbOn]} />
              </TouchableOpacity>
            </View>

            <View style={s.navRow}>
              <TouchableOpacity style={s.backStepBtn} onPress={() => setStep('teams')}>
                <Text style={s.backStepText}>‹ Back</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.nextBtn} onPress={() => setStep('review')}>
                <Text style={s.nextBtnText}>Review ›</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* ── STEP 4: Review & Confirm ── */}
        {step === 'review' && (
          <View>
            <Text style={s.stepTitle}>Review Match</Text>
            <Text style={s.stepDesc}>Confirm everything before creating the match.</Text>

            <View style={s.reviewCard}>
              <ReviewRow label="Type"       value={isStandalone ? 'Standalone' : 'Tournament Match'} />
              {!isStandalone && <ReviewRow label="Tournament" value={db.tournaments.getById(tournamentId)?.name || '—'} />}
              <ReviewRow label="Team 1"     value={`${team1?.name} ${team1XIReady ? '✓' : '⚠'}`} />
              <ReviewRow label="Team 2"     value={`${team2?.name} ${team2XIReady ? '✓' : '⚠'}`} />
              <ReviewRow label="Venue"      value={venue} />
              <ReviewRow label="Format"     value={`${format} · ${totalOvers} overs`} />
              <ReviewRow label="Powerplays" value={powerplays.length > 0 ? powerplays.map(p => `${p.label}: ${p.fromOver}-${p.toOver}`).join(', ') : 'None'} />
              <ReviewRow label="Super Over" value={hasSuperOver ? 'Yes' : 'No'} />
            </View>

            {(!team1XIReady || !team2XIReady) && (
              <View style={s.warnBox}>
                <Text style={s.warnText}>
                  ⚠ One or both teams do not have a locked Playing XI.{'\n'}
                  The match can be created, but scoring cannot start until both teams lock their XI.
                </Text>
              </View>
            )}

            <Text style={s.infoNote}>
              ℹ Toss will be conducted once the scorer activates via token.{'\n'}
              Token is generated from the Token Generator screen.
            </Text>

            <View style={s.navRow}>
              <TouchableOpacity style={s.backStepBtn} onPress={() => setStep('config')}>
                <Text style={s.backStepText}>‹ Back</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[s.createBtn, loading && s.createBtnDisabled]}
                onPress={handleCreate}
                disabled={loading}
              >
                <Text style={s.createBtnText}>{loading ? 'Creating...' : 'Create Match'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

      </ScrollView>
    </View>
  );
};

const ReviewRow = ({ label, value }: { label: string; value: string }) => (
  <View style={s.reviewRow}>
    <Text style={s.reviewLabel}>{label}</Text>
    <Text style={s.reviewValue}>{value}</Text>
  </View>
);

const s = StyleSheet.create({
  screen:             { flex: 1, backgroundColor: T.colors.bg },
  header:             { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: T.colors.border },
  backBtn:            { width: 60 },
  backText:           { fontSize: 16, color: T.colors.gold, fontWeight: '600' },
  headerCenter:       { flex: 1, alignItems: 'center' },
  headerTitle:        { fontSize: 18, fontWeight: '800', color: T.colors.text },
  headerSub:          { fontSize: 11, color: T.colors.textMuted, marginTop: 2 },
  stepRow:            { flexDirection: 'row', justifyContent: 'center', gap: 8, paddingVertical: 16 },
  stepDot:            { width: 8, height: 8, borderRadius: 4, backgroundColor: T.colors.bgElevated, borderWidth: 1, borderColor: T.colors.border },
  stepDotActive:      { backgroundColor: T.colors.gold, borderColor: T.colors.gold, width: 24 },
  stepDotDone:        { backgroundColor: T.colors.emerald, borderColor: T.colors.emerald },
  scroll:             { flex: 1 },
  content:            { padding: 20, paddingBottom: 60 },
  stepTitle:          { fontSize: 22, fontWeight: '800', color: T.colors.text, marginBottom: 6 },
  stepDesc:           { fontSize: 13, color: T.colors.textMuted, marginBottom: 24, lineHeight: 18 },
  typeCard:           { flexDirection: 'row', alignItems: 'center', padding: 16, borderRadius: T.radius.lg, borderWidth: 1.5, borderColor: T.colors.border, backgroundColor: T.colors.bgCard, marginBottom: 12 },
  typeCardActive:     { borderColor: T.colors.gold, backgroundColor: T.colors.goldBg },
  typeIcon:           { fontSize: 26, marginRight: 14 },
  typeInfo:           { flex: 1 },
  typeLabel:          { fontSize: 15, fontWeight: '700', color: T.colors.textSub },
  typeLabelActive:    { color: T.colors.goldLight },
  typeDesc:           { fontSize: 12, color: T.colors.textMuted, marginTop: 2 },
  checkMark:          { fontSize: 18, color: T.colors.gold, fontWeight: '800' },
  fieldLabel:         { fontSize: 11, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 1.5, marginBottom: 10, marginTop: 20 },
  optionRow:          { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 14, borderRadius: T.radius.md, borderWidth: 1, borderColor: T.colors.border, backgroundColor: T.colors.bgCard, marginBottom: 8 },
  optionActive:       { borderColor: T.colors.gold, backgroundColor: T.colors.goldBg },
  optionText:         { fontSize: 14, fontWeight: '600', color: T.colors.textSub },
  optionTextActive:   { color: T.colors.goldLight },
  optionMeta:         { fontSize: 11, color: T.colors.textMuted },
  teamGrid:           { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 8 },
  teamChip:           { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 10, borderRadius: T.radius.md, borderWidth: 1.5, borderColor: T.colors.border, backgroundColor: T.colors.bgCard },
  teamChipActive:     { borderColor: T.colors.gold, backgroundColor: T.colors.goldBg },
  teamChipDisabled:   { opacity: 0.35 },
  teamColorDot:       { width: 10, height: 10, borderRadius: 5 },
  teamChipText:       { fontSize: 13, fontWeight: '600', color: T.colors.textSub },
  teamChipTextActive: { color: T.colors.goldLight },
  teamChipCheck:      { fontSize: 13, color: T.colors.gold, fontWeight: '800' },
  xiAlert:            { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 10, borderRadius: T.radius.md, marginBottom: 8 },
  xiAlertOk:          { backgroundColor: T.colors.emeraldBg },
  xiAlertWarn:        { backgroundColor: T.colors.redBg },
  xiAlertText:        { fontSize: 12, color: T.colors.textSub, flex: 1 },
  xiFixBtn:           { fontSize: 12, color: T.colors.gold, fontWeight: '700' },
  textInput:          { backgroundColor: T.colors.bgInput, borderRadius: T.radius.md, borderWidth: 1, borderColor: T.colors.border, color: T.colors.text, padding: 14, fontSize: 15 },
  formatGrid:         { flexDirection: 'row', gap: 8, marginBottom: 8 },
  formatBtn:          { flex: 1, padding: 12, borderRadius: T.radius.md, borderWidth: 1.5, borderColor: T.colors.border, backgroundColor: T.colors.bgCard, alignItems: 'center' },
  formatBtnActive:    { borderColor: T.colors.gold, backgroundColor: T.colors.goldBg },
  formatBtnLabel:     { fontSize: 13, fontWeight: '700', color: T.colors.textSub },
  formatBtnLabelActive:{ color: T.colors.goldLight },
  formatBtnSub:       { fontSize: 10, color: T.colors.textMuted, marginTop: 2 },
  ppRow:              { flexDirection: 'row', justifyContent: 'space-between', padding: 10, borderRadius: T.radius.sm, backgroundColor: T.colors.bgElevated, marginBottom: 6 },
  ppLabel:            { fontSize: 12, fontWeight: '700', color: T.colors.goldLight },
  ppRange:            { fontSize: 12, color: T.colors.textMuted },
  noData:             { fontSize: 12, color: T.colors.textMuted, padding: 8 },
  toggleRow:          { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 16, borderTopWidth: 1, borderTopColor: T.colors.borderLight, marginTop: 16 },
  toggleLabel:        { fontSize: 14, fontWeight: '600', color: T.colors.text },
  toggle:             { width: 48, height: 28, borderRadius: 14, backgroundColor: T.colors.bgElevated, borderWidth: 1, borderColor: T.colors.border, justifyContent: 'center', paddingHorizontal: 3 },
  toggleOn:           { backgroundColor: T.colors.emeraldDim, borderColor: T.colors.emerald },
  toggleThumb:        { width: 22, height: 22, borderRadius: 11, backgroundColor: T.colors.textMuted },
  toggleThumbOn:      { backgroundColor: T.colors.emerald, alignSelf: 'flex-end' },
  navRow:             { flexDirection: 'row', gap: 12, marginTop: 28 },
  backStepBtn:        { flex: 1, padding: 14, borderRadius: T.radius.lg, borderWidth: 1, borderColor: T.colors.border, alignItems: 'center' },
  backStepText:       { fontSize: 14, fontWeight: '600', color: T.colors.textSub },
  nextBtn:            { flex: 2, padding: 14, borderRadius: T.radius.lg, backgroundColor: T.colors.gold, alignItems: 'center', ...T.shadow.gold },
  nextBtnDisabled:    { backgroundColor: T.colors.bgElevated, shadowOpacity: 0 },
  nextBtnText:        { fontSize: 15, fontWeight: '800', color: T.colors.bg },
  reviewCard:         { backgroundColor: T.colors.bgCard, borderRadius: T.radius.lg, padding: 16, borderWidth: 1, borderColor: T.colors.border, marginBottom: 16 },
  reviewRow:          { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: T.colors.borderLight },
  reviewLabel:        { fontSize: 12, color: T.colors.textMuted, fontWeight: '600' },
  reviewValue:        { fontSize: 13, color: T.colors.text, fontWeight: '600', flex: 1, textAlign: 'right' },
  warnBox:            { padding: 14, borderRadius: T.radius.md, backgroundColor: T.colors.orangeBg, borderWidth: 1, borderColor: T.colors.orange + '44', marginBottom: 12 },
  warnText:           { fontSize: 12, color: T.colors.orange, lineHeight: 18 },
  warnBtn:            { marginTop: 8 },
  warnBtnText:        { fontSize: 12, color: T.colors.gold, fontWeight: '700' },
  infoNote:           { fontSize: 12, color: T.colors.textMuted, backgroundColor: T.colors.bgElevated, padding: 12, borderRadius: T.radius.md, lineHeight: 18, marginBottom: 8 },
  createBtn:          { flex: 2, padding: 16, borderRadius: T.radius.lg, backgroundColor: T.colors.emerald, alignItems: 'center' },
  createBtnDisabled:  { opacity: 0.5 },
  createBtnText:      { fontSize: 15, fontWeight: '800', color: T.colors.bg },
});
