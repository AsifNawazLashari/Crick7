// Cricket A7 — Organizer Dashboard | Asif Lashari | A7 Studio
// FULLY DYNAMIC — no static data on screen
import React, { useCallback, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  RefreshControl, StatusBar, Animated,
} from 'react-native';
import { theme } from '../../theme';
import { db } from '../../data/db';
import { Match, Tournament } from '../../types';

interface Props { onNavigate: (screen: string, params?: any) => void; onLogout: () => void; }

const T = theme;

// ── helpers ──────────────────────────────────────────────────────────────────
const formatDate = (ts: number) => new Date(ts).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' });
const formatTime = (ts: number) => new Date(ts).toLocaleTimeString('en-PK', { hour: '2-digit', minute: '2-digit' });

export const OrganizerDashboard: React.FC<Props> = ({ onNavigate, onLogout }) => {
  const [refreshing, setRefreshing] = useState(false);
  const [tick, setTick] = useState(0); // force re-render on refresh

  const refresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => { setRefreshing(false); setTick(t => t + 1); }, 600);
  }, []);

  // ── Live data — computed fresh every render ──────────────────────────────
  const user        = db.auth.getCurrentUser()!;
  const tournaments = db.tournaments.getAll().filter(t => t.organizerId === user.id);
  const allMatches  = db.matches.getAll().filter(m =>
    tournaments.some(t => t.id === m.tournamentId) || !m.tournamentId
  );
  const liveMatches   = allMatches.filter(m => m.status === 'live');
  const todayTs       = new Date().setHours(0, 0, 0, 0);
  const upcomingToday = allMatches.filter(m =>
    m.status === 'scheduled' && m.scheduledAt >= todayTs && m.scheduledAt < todayTs + 86400000
  );
  const needsToken = allMatches.filter(m =>
    m.status === 'scheduled' && !m.scorerToken &&
    m.scheduledAt >= Date.now() - 3600000
  );
  const allPlayers = db.players.getAll();
  const allTeams   = db.teams.getAll();

  // ── Stats ────────────────────────────────────────────────────────────────
  const statsCards = [
    { label: 'Tournaments',  value: tournaments.length,                color: T.colors.gold },
    { label: 'Live Now',     value: liveMatches.length,                color: T.colors.red },
    { label: 'Teams',        value: allTeams.length,                   color: T.colors.emerald },
    { label: 'Players',      value: allPlayers.length,                 color: T.colors.purple },
    { label: 'Matches',      value: allMatches.length,                 color: T.colors.blue },
    { label: 'Today',        value: upcomingToday.length,              color: T.colors.orange },
  ];

  return (
    <View style={s.screen}>
      <StatusBar barStyle="light-content" backgroundColor={T.colors.bg} />

      {/* ── Header ── */}
      <View style={s.header}>
        <View>
          <Text style={s.logoText}>CRICKET A7</Text>
          <Text style={s.headerSub}>Organizer · {user.name}</Text>
        </View>
        <View style={s.headerRight}>
          {liveMatches.length > 0 && (
            <View style={s.livePill}>
              <View style={s.liveDot} />
              <Text style={s.livePillText}>{liveMatches.length} LIVE</Text>
            </View>
          )}
          <TouchableOpacity onPress={onLogout} style={s.logoutBtn}>
            <Text style={s.logoutText}>EXIT</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={T.colors.gold} />}
      >

        {/* ── Alerts ── */}
        {needsToken.length > 0 && (
          <TouchableOpacity style={s.alertBanner} onPress={() => onNavigate('TokenGenerate')}>
            <Text style={s.alertIcon}>🔑</Text>
            <View style={s.alertInfo}>
              <Text style={s.alertTitle}>{needsToken.length} match{needsToken.length > 1 ? 'es' : ''} need a scorer token</Text>
              <Text style={s.alertSub}>Tap to generate tokens</Text>
            </View>
            <Text style={s.alertArrow}>›</Text>
          </TouchableOpacity>
        )}

        {/* ── Live matches ── */}
        {liveMatches.length > 0 && (
          <View style={s.section}>
            <Text style={s.sectionTitle}>LIVE NOW</Text>
            {liveMatches.map(m => <LiveMatchCard key={m.id} match={m} onPress={() => onNavigate('MatchDetail', { matchId: m.id })} />)}
          </View>
        )}

        {/* ── Stats row ── */}
        <View style={s.section}>
          <Text style={s.sectionTitle}>OVERVIEW</Text>
          <View style={s.statsGrid}>
            {statsCards.map(s2 => (
              <View key={s2.label} style={[s.statCard, { borderColor: s2.color + '33' }]}>
                <Text style={[s.statValue, { color: s2.color }]}>{s2.value}</Text>
                <Text style={s.statLabel}>{s2.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* ── Today's matches ── */}
        {upcomingToday.length > 0 && (
          <View style={s.section}>
            <Text style={s.sectionTitle}>TODAY'S MATCHES</Text>
            {upcomingToday.map(m => <UpcomingMatchCard key={m.id} match={m} onPress={() => onNavigate('MatchDetail', { matchId: m.id })} />)}
          </View>
        )}

        {/* ── Quick actions ── */}
        <View style={s.section}>
          <Text style={s.sectionTitle}>MANAGEMENT</Text>
          <View style={s.actionGrid}>
            {ACTIONS.map(a => (
              <TouchableOpacity key={a.screen} style={s.actionCard} onPress={() => onNavigate(a.screen)} activeOpacity={0.75}>
                <Text style={[s.actionIcon, { color: a.color }]}>{a.icon}</Text>
                <Text style={s.actionLabel}>{a.label}</Text>
                <Text style={s.actionDesc}>{a.desc}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* ── Recent tournaments ── */}
        {tournaments.length > 0 && (
          <View style={s.section}>
            <SectionHeader title="TOURNAMENTS" onMore={() => onNavigate('TournamentCreate')} moreLabel="Manage" />
            {tournaments.slice(0, 3).map(t => (
              <TournamentCard key={t.id} tournament={t} onPress={() => onNavigate('TournamentDetail', { tournamentId: t.id })} />
            ))}
          </View>
        )}

        {/* ── Empty state ── */}
        {tournaments.length === 0 && allMatches.length === 0 && (
          <View style={s.emptyWrap}>
            <Text style={s.emptyIcon}>🏏</Text>
            <Text style={s.emptyTitle}>Nothing here yet</Text>
            <Text style={s.emptyDesc}>Create a tournament or a standalone match to get started.</Text>
            <TouchableOpacity style={s.emptyBtn} onPress={() => onNavigate('TournamentCreate')}>
              <Text style={s.emptyBtnText}>Create Tournament</Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={s.footer}>
          <Text style={s.footerText}>Cricket A7 · A7 Studio · Asif Nawaz Lashari</Text>
        </View>
      </ScrollView>
    </View>
  );
};

// ── Sub-components ────────────────────────────────────────────────────────────
const LiveMatchCard = ({ match, onPress }: { match: Match; onPress: () => void }) => {
  const t1 = db.teams.getById(match.team1Id);
  const t2 = db.teams.getById(match.team2Id);
  const innings = db.innings.getByMatch(match.id);
  const ci = innings.find(i => i.status === 'ongoing');
  return (
    <TouchableOpacity style={[ls.card, ls.liveCard]} onPress={onPress} activeOpacity={0.8}>
      <View style={ls.liveHeaderRow}>
        <View style={ls.liveBadge}><View style={ls.liveDot} /><Text style={ls.liveBadgeText}>LIVE</Text></View>
        <Text style={ls.venue}>📍 {match.venue}</Text>
      </View>
      <View style={ls.teamsRow}>
        <View style={ls.teamBlock}>
          <View style={[ls.teamDot, { backgroundColor: t1?.color || T.colors.gold }]} />
          <Text style={ls.teamName}>{t1?.name}</Text>
        </View>
        {ci && <Text style={ls.liveScore}>{ci.totalRuns}/{ci.wickets}</Text>}
        <Text style={ls.vsText}>VS</Text>
        <View style={[ls.teamBlock, ls.teamBlockRight]}>
          <Text style={ls.teamName}>{t2?.name}</Text>
          <View style={[ls.teamDot, { backgroundColor: t2?.color || T.colors.emerald }]} />
        </View>
      </View>
      {ci && (
        <Text style={ls.oversText}>
          {Math.floor(ci.legalBalls / 6)}.{ci.legalBalls % 6} ov · Target: {ci.target ?? '—'}
        </Text>
      )}
    </TouchableOpacity>
  );
};

const UpcomingMatchCard = ({ match, onPress }: { match: Match; onPress: () => void }) => {
  const t1 = db.teams.getById(match.team1Id);
  const t2 = db.teams.getById(match.team2Id);
  return (
    <TouchableOpacity style={ls.card} onPress={onPress} activeOpacity={0.8}>
      <View style={ls.upRow}>
        <View style={ls.teamBlock}>
          <View style={[ls.teamDot, { backgroundColor: t1?.color || T.colors.gold }]} />
          <Text style={ls.teamName}>{t1?.name}</Text>
        </View>
        <View style={ls.upCenter}>
          <Text style={ls.upTime}>{formatTime(match.scheduledAt)}</Text>
          <Text style={ls.upFormat}>{match.format} · {match.totalOvers} ov</Text>
        </View>
        <View style={[ls.teamBlock, ls.teamBlockRight]}>
          <Text style={ls.teamName}>{t2?.name}</Text>
          <View style={[ls.teamDot, { backgroundColor: t2?.color || T.colors.emerald }]} />
        </View>
      </View>
      <View style={ls.upFooter}>
        <Text style={ls.venue}>📍 {match.venue}</Text>
        <View style={[ls.statusPill, { backgroundColor: match.scorerToken ? T.colors.emeraldBg : T.colors.redBg }]}>
          <Text style={[ls.statusText, { color: match.scorerToken ? T.colors.emerald : T.colors.red }]}>
            {match.scorerToken ? 'TOKEN READY' : 'NO TOKEN'}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const TournamentCard = ({ tournament, onPress }: { tournament: Tournament; onPress: () => void }) => (
  <TouchableOpacity style={ls.card} onPress={onPress} activeOpacity={0.8}>
    <View style={ls.tRow}>
      <View style={ls.tInfo}>
        <Text style={ls.tName}>{tournament.name}</Text>
        <Text style={ls.tMeta}>{tournament.format} · {tournament.totalOvers} ov · {tournament.teamIds.length} teams · {tournament.matchIds.length} matches</Text>
      </View>
      <View style={[ls.statusPill, { backgroundColor: T.colors.status[tournament.status as 'upcoming']+'22' }]}>
        <Text style={[ls.statusText, { color: T.colors.status[tournament.status as 'upcoming'] }]}>
          {tournament.status.toUpperCase()}
        </Text>
      </View>
    </View>
  </TouchableOpacity>
);

const SectionHeader = ({ title, onMore, moreLabel }: { title: string; onMore?: () => void; moreLabel?: string }) => (
  <View style={ls.secHeader}>
    <Text style={ls.secTitle}>{title}</Text>
    {onMore && <TouchableOpacity onPress={onMore}><Text style={ls.secMore}>{moreLabel} ›</Text></TouchableOpacity>}
  </View>
);

const ACTIONS = [
  { screen: 'TournamentCreate', label: 'Tournaments', desc: 'Create & manage', icon: '🏆', color: T.colors.gold },
  { screen: 'MatchSetup',       label: 'New Match',   desc: 'Setup a match',  icon: '⚔️',  color: T.colors.red },
  { screen: 'TeamManage',       label: 'Teams',       desc: 'Manage teams',   icon: '👥',  color: T.colors.emerald },
  { screen: 'Fixture',          label: 'Fixtures',    desc: 'Schedule view',  icon: '📅',  color: T.colors.blue },
  { screen: 'TokenGenerate',    label: 'Tokens',      desc: 'Scorer access',  icon: '🔑',  color: T.colors.orange },
  { screen: 'Stats',            label: 'Stats',       desc: 'Analytics',      icon: '📊',  color: T.colors.purple },
];

// ── Styles ────────────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  screen:        { flex: 1, backgroundColor: T.colors.bg },
  header:        { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 52, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: T.colors.border },
  logoText:      { fontSize: 20, fontWeight: '900', color: T.colors.goldLight, letterSpacing: 3 },
  headerSub:     { fontSize: 11, color: T.colors.textMuted, marginTop: 2, letterSpacing: 1 },
  headerRight:   { flexDirection: 'row', alignItems: 'center', gap: 10 },
  livePill:      { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: T.colors.redBg, paddingHorizontal: 10, paddingVertical: 5, borderRadius: T.radius.full, borderWidth: 1, borderColor: T.colors.red + '44' },
  liveDot:       { width: 6, height: 6, borderRadius: 3, backgroundColor: T.colors.red },
  livePillText:  { fontSize: 10, fontWeight: '800', color: T.colors.red, letterSpacing: 1 },
  logoutBtn:     { paddingHorizontal: 12, paddingVertical: 6, borderRadius: T.radius.md, borderWidth: 1, borderColor: T.colors.border },
  logoutText:    { fontSize: 11, color: T.colors.textMuted, fontWeight: '700', letterSpacing: 1 },
  alertBanner:   { margin: 16, padding: 14, backgroundColor: T.colors.orangeBg, borderRadius: T.radius.lg, borderWidth: 1, borderColor: T.colors.orange + '44', flexDirection: 'row', alignItems: 'center', gap: 12 },
  alertIcon:     { fontSize: 22 },
  alertInfo:     { flex: 1 },
  alertTitle:    { fontSize: 13, fontWeight: '700', color: T.colors.orange },
  alertSub:      { fontSize: 11, color: T.colors.textMuted, marginTop: 2 },
  alertArrow:    { fontSize: 20, color: T.colors.orange },
  section:       { paddingHorizontal: 16, marginBottom: 8 },
  sectionTitle:  { fontSize: 11, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 2, marginBottom: 12, marginTop: 20 },
  statsGrid:     { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  statCard:      { width: '30.5%', backgroundColor: T.colors.bgCard, borderRadius: T.radius.lg, padding: 14, borderWidth: 1, alignItems: 'center', ...T.shadow.sm },
  statValue:     { fontSize: 26, fontWeight: '900' },
  statLabel:     { fontSize: 10, color: T.colors.textMuted, marginTop: 4, fontWeight: '600', letterSpacing: 0.5 },
  actionGrid:    { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  actionCard:    { width: '47%', backgroundColor: T.colors.bgCard, borderRadius: T.radius.lg, padding: 16, borderWidth: 1, borderColor: T.colors.border, ...T.shadow.sm },
  actionIcon:    { fontSize: 26, marginBottom: 8 },
  actionLabel:   { fontSize: 13, fontWeight: '700', color: T.colors.text },
  actionDesc:    { fontSize: 11, color: T.colors.textMuted, marginTop: 3 },
  emptyWrap:     { alignItems: 'center', padding: 48 },
  emptyIcon:     { fontSize: 52, marginBottom: 16 },
  emptyTitle:    { fontSize: 20, fontWeight: '800', color: T.colors.text, marginBottom: 8 },
  emptyDesc:     { fontSize: 13, color: T.colors.textMuted, textAlign: 'center', lineHeight: 20, marginBottom: 24 },
  emptyBtn:      { backgroundColor: T.colors.gold, paddingHorizontal: 24, paddingVertical: 12, borderRadius: T.radius.lg },
  emptyBtnText:  { fontSize: 14, fontWeight: '800', color: T.colors.bg },
  footer:        { padding: 32, alignItems: 'center' },
  footerText:    { fontSize: 10, color: T.colors.textMuted, letterSpacing: 1 },
});

const ls = StyleSheet.create({
  card:           { backgroundColor: T.colors.bgCard, borderRadius: T.radius.lg, padding: 14, marginBottom: 10, borderWidth: 1, borderColor: T.colors.border, ...T.shadow.sm },
  liveCard:       { borderColor: T.colors.red + '44', backgroundColor: T.colors.redBg },
  liveHeaderRow:  { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  liveBadge:      { flexDirection: 'row', alignItems: 'center', gap: 5 },
  liveDot:        { width: 7, height: 7, borderRadius: 4, backgroundColor: T.colors.red },
  liveBadgeText:  { fontSize: 10, fontWeight: '800', color: T.colors.red, letterSpacing: 1.5 },
  teamsRow:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  teamBlock:      { flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 },
  teamBlockRight: { justifyContent: 'flex-end' },
  teamDot:        { width: 10, height: 10, borderRadius: 5 },
  teamName:       { fontSize: 14, fontWeight: '700', color: T.colors.text },
  liveScore:      { fontSize: 22, fontWeight: '900', color: T.colors.goldLight, marginHorizontal: 8 },
  vsText:         { fontSize: 11, fontWeight: '700', color: T.colors.textMuted, paddingHorizontal: 8 },
  oversText:      { fontSize: 11, color: T.colors.textMuted, marginTop: 8, textAlign: 'center' },
  upRow:          { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  upCenter:       { alignItems: 'center' },
  upTime:         { fontSize: 16, fontWeight: '800', color: T.colors.goldLight },
  upFormat:       { fontSize: 10, color: T.colors.textMuted, marginTop: 2 },
  upFooter:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 10, borderTopWidth: 1, borderTopColor: T.colors.borderLight },
  venue:          { fontSize: 11, color: T.colors.textMuted },
  statusPill:     { paddingHorizontal: 8, paddingVertical: 3, borderRadius: T.radius.full },
  statusText:     { fontSize: 9, fontWeight: '800', letterSpacing: 1 },
  tRow:           { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  tInfo:          { flex: 1, marginRight: 10 },
  tName:          { fontSize: 15, fontWeight: '700', color: T.colors.text },
  tMeta:          { fontSize: 11, color: T.colors.textMuted, marginTop: 3 },
  secHeader:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  secTitle:       { fontSize: 11, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 2, marginTop: 20 },
  secMore:        { fontSize: 12, color: T.colors.gold, fontWeight: '700', marginTop: 20 },
});
