// Cricket A7 — Token Generate Screen | Asif Lashari | A7 Studio
// FIXES:
//   - Shows only scheduled matches without tokens first, then all
//   - Token stored directly on match record (not separate collection)
//   - Revoke token option
//   - Share via native Share API
import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  Share, StatusBar, Alert,
} from 'react-native';
import { theme } from '../../theme';
import { db } from '../../data/db';
import { Match } from '../../types';

const T = theme;
interface Props { onBack: () => void; matchId?: string; }

export const TokenGenerateScreen: React.FC<Props> = ({ onBack, matchId: preselectedId }) => {
  const [selectedId, setSelected] = useState<string | null>(preselectedId || null);
  const [generated, setGenerated]  = useState<string | null>(null);
  const [tick, setTick]            = useState(0);

  const forceRefresh = () => setTick(t => t + 1);

  const eligibleMatches = db.matches.getAll().filter(m =>
    ['scheduled', 'toss_pending'].includes(m.status)
  );

  const selectedMatch = selectedId ? db.matches.getById(selectedId) : null;
  const t1 = selectedMatch ? db.teams.getById(selectedMatch.team1Id) : null;
  const t2 = selectedMatch ? db.teams.getById(selectedMatch.team2Id) : null;

  const handleGenerate = useCallback(() => {
    if (!selectedId) return;
    const token = db.matches.generateToken(selectedId);
    setGenerated(token);
    forceRefresh();
  }, [selectedId]);

  const handleRevoke = () => {
    if (!selectedId) return;
    Alert.alert('Revoke Token', 'This will disable the current scorer session. Continue?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Revoke', style: 'destructive', onPress: () => {
          db.matches.update(selectedId, { scorerToken: null, scorerUserId: null, status: 'scheduled' });
          setGenerated(null);
          forceRefresh();
        }
      },
    ]);
  };

  const handleShare = async () => {
    if (!generated || !selectedMatch) return;
    const msg = `Cricket A7 — Scorer Token\n\nToken: ${generated}\n\nMatch: ${t1?.name} vs ${t2?.name}\nVenue: ${selectedMatch.venue}\n\nEnter this token in the Cricket A7 app to start live scoring.`;
    await Share.share({ message: msg, title: 'Cricket A7 Scorer Token' });
  };

  const formatDate = (ts: number) => new Date(ts).toLocaleString('en-PK', { dateStyle: 'short', timeStyle: 'short' });

  return (
    <View style={s.screen}>
      <StatusBar barStyle="light-content" />
      <View style={s.header}>
        <TouchableOpacity onPress={onBack} style={s.backBtn}>
          <Text style={s.backText}>‹</Text>
        </TouchableOpacity>
        <View style={s.headerCenter}>
          <Text style={s.headerTitle}>Token Generator</Text>
          <Text style={s.headerSub}>Scorer access control</Text>
        </View>
        <View style={{ width: 40 }} />
      </View>

      <FlatList
        data={eligibleMatches}
        keyExtractor={m => m.id}
        contentContainerStyle={s.list}
        ListHeaderComponent={
          <>
            {/* Info box */}
            <View style={s.infoBox}>
              <Text style={s.infoText}>
                Select a match and generate a token. Share the token with your scorer. They enter it to unlock live scoring for that match only.
              </Text>
            </View>

            {/* Generated token display */}
            {generated && selectedMatch && (
              <View style={s.tokenCard}>
                <Text style={s.tokenCardLabel}>TOKEN GENERATED</Text>
                <Text style={s.tokenCode}>{generated}</Text>
                <Text style={s.tokenMatch}>{t1?.name} vs {t2?.name}</Text>
                <Text style={s.tokenVenue}>📍 {selectedMatch.venue}</Text>
                <View style={s.tokenActions}>
                  <TouchableOpacity style={s.shareBtn} onPress={handleShare}>
                    <Text style={s.shareBtnText}>📤 Share Token</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={s.revokeBtn} onPress={handleRevoke}>
                    <Text style={s.revokeBtnText}>Revoke</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}

            <Text style={s.sectionLabel}>SELECT MATCH</Text>
          </>
        }
        renderItem={({ item: m }) => {
          const mt1 = db.teams.getById(m.team1Id);
          const mt2 = db.teams.getById(m.team2Id);
          const hasToken = !!m.scorerToken;
          const isSelected = selectedId === m.id;
          return (
            <TouchableOpacity
              style={[s.matchCard, isSelected && s.matchCardActive, hasToken && s.matchCardHasToken]}
              onPress={() => { setSelected(m.id); setGenerated(m.scorerToken); }}
              activeOpacity={0.8}
            >
              <View style={s.matchCardHeader}>
                <View style={s.matchTeamsRow}>
                  <View style={[s.teamDot, { backgroundColor: mt1?.color || T.colors.gold }]} />
                  <Text style={s.matchTeamText}>{mt1?.name}</Text>
                  <Text style={s.matchVs}>vs</Text>
                  <Text style={s.matchTeamText}>{mt2?.name}</Text>
                  <View style={[s.teamDot, { backgroundColor: mt2?.color || T.colors.emerald }]} />
                </View>
                <View style={[s.tokenStatusBadge, { backgroundColor: hasToken ? T.colors.emeraldBg : T.colors.redBg }]}>
                  <Text style={[s.tokenStatusText, { color: hasToken ? T.colors.emerald : T.colors.red }]}>
                    {hasToken ? 'TOKEN ACTIVE' : 'NO TOKEN'}
                  </Text>
                </View>
              </View>
              <Text style={s.matchDateText}>📅 {formatDate(m.scheduledAt)}  📍 {m.venue}</Text>
              {hasToken && m.scorerToken && (
                <Text style={s.existingToken}>Current: {m.scorerToken}</Text>
              )}
              {isSelected && !hasToken && (
                <TouchableOpacity style={s.generateInlineBtn} onPress={handleGenerate}>
                  <Text style={s.generateInlineBtnText}>🔑 Generate Token</Text>
                </TouchableOpacity>
              )}
              {isSelected && hasToken && (
                <View style={s.inlineActions}>
                  <TouchableOpacity style={s.regenerateBtn} onPress={handleGenerate}>
                    <Text style={s.regenerateBtnText}>Regenerate</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={s.shareSmallBtn} onPress={handleShare}>
                    <Text style={s.shareSmallBtnText}>Share ↗</Text>
                  </TouchableOpacity>
                </View>
              )}
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={
          <View style={s.empty}>
            <Text style={s.emptyIcon}>🔑</Text>
            <Text style={s.emptyTitle}>No eligible matches</Text>
            <Text style={s.emptySub}>Create a match first to generate a token.</Text>
          </View>
        }
      />
    </View>
  );
};

const s = StyleSheet.create({
  screen:              { flex: 1, backgroundColor: T.colors.bg },
  header:              { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: T.colors.border },
  backBtn:             { width: 40 },
  backText:            { fontSize: 22, color: T.colors.gold, fontWeight: '600' },
  headerCenter:        { flex: 1, alignItems: 'center' },
  headerTitle:         { fontSize: 18, fontWeight: '800', color: T.colors.text },
  headerSub:           { fontSize: 11, color: T.colors.textMuted, marginTop: 2 },
  list:                { padding: 16, paddingBottom: 60 },
  infoBox:             { backgroundColor: T.colors.bgElevated, borderRadius: T.radius.lg, padding: 14, marginBottom: 20, borderWidth: 1, borderColor: T.colors.border },
  infoText:            { fontSize: 12, color: T.colors.textMuted, lineHeight: 18 },
  tokenCard:           { backgroundColor: T.colors.bgCard, borderRadius: T.radius.xl, padding: 20, marginBottom: 24, borderWidth: 1, borderColor: T.colors.gold + '44', alignItems: 'center', ...T.shadow.gold },
  tokenCardLabel:      { fontSize: 9, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 2, marginBottom: 12 },
  tokenCode:           { fontSize: 28, fontWeight: '900', color: T.colors.goldLight, letterSpacing: 4, fontFamily: 'Courier New', marginBottom: 10 },
  tokenMatch:          { fontSize: 14, fontWeight: '700', color: T.colors.text, marginBottom: 4 },
  tokenVenue:          { fontSize: 11, color: T.colors.textMuted, marginBottom: 16 },
  tokenActions:        { flexDirection: 'row', gap: 10, width: '100%' },
  shareBtn:            { flex: 2, backgroundColor: T.colors.emerald, padding: 12, borderRadius: T.radius.lg, alignItems: 'center' },
  shareBtnText:        { fontSize: 14, fontWeight: '800', color: T.colors.bg },
  revokeBtn:           { flex: 1, borderWidth: 1, borderColor: T.colors.red + '55', padding: 12, borderRadius: T.radius.lg, alignItems: 'center' },
  revokeBtnText:       { fontSize: 13, fontWeight: '700', color: T.colors.red },
  sectionLabel:        { fontSize: 10, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 2, marginBottom: 12 },
  matchCard:           { backgroundColor: T.colors.bgCard, borderRadius: T.radius.lg, padding: 14, marginBottom: 10, borderWidth: 1.5, borderColor: T.colors.border, ...T.shadow.sm },
  matchCardActive:     { borderColor: T.colors.gold },
  matchCardHasToken:   { borderColor: T.colors.emerald + '55' },
  matchCardHeader:     { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  matchTeamsRow:       { flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 },
  teamDot:             { width: 8, height: 8, borderRadius: 4 },
  matchTeamText:       { fontSize: 13, fontWeight: '700', color: T.colors.text },
  matchVs:             { fontSize: 10, color: T.colors.textMuted },
  tokenStatusBadge:    { paddingHorizontal: 8, paddingVertical: 3, borderRadius: T.radius.full },
  tokenStatusText:     { fontSize: 8, fontWeight: '800', letterSpacing: 1.5 },
  matchDateText:       { fontSize: 11, color: T.colors.textMuted },
  existingToken:       { fontSize: 12, color: T.colors.gold, fontFamily: 'Courier New', marginTop: 6, letterSpacing: 1 },
  generateInlineBtn:   { marginTop: 12, backgroundColor: T.colors.gold, padding: 12, borderRadius: T.radius.md, alignItems: 'center', ...T.shadow.gold },
  generateInlineBtnText:{ fontSize: 14, fontWeight: '800', color: T.colors.bg },
  inlineActions:       { flexDirection: 'row', gap: 8, marginTop: 12 },
  regenerateBtn:       { flex: 1, borderWidth: 1, borderColor: T.colors.border, padding: 10, borderRadius: T.radius.md, alignItems: 'center' },
  regenerateBtnText:   { fontSize: 12, fontWeight: '600', color: T.colors.textMuted },
  shareSmallBtn:       { flex: 1, backgroundColor: T.colors.emeraldBg, padding: 10, borderRadius: T.radius.md, alignItems: 'center', borderWidth: 1, borderColor: T.colors.emerald + '44' },
  shareSmallBtnText:   { fontSize: 12, fontWeight: '700', color: T.colors.emerald },
  empty:               { alignItems: 'center', paddingVertical: 60 },
  emptyIcon:           { fontSize: 48, marginBottom: 12 },
  emptyTitle:          { fontSize: 16, fontWeight: '800', color: T.colors.text, marginBottom: 6 },
  emptySub:            { fontSize: 12, color: T.colors.textMuted, textAlign: 'center' },
});
