// Cricket A7 — Select Openers + Opening Bowler | Asif Lashari | A7 Studio
// Two-step: first pick 2 openers (striker + non-striker), then pick opening bowler
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  TouchableOpacity, StatusBar,
} from 'react-native';
import { theme } from '../../theme';
import { db } from '../../data/db';
import { Player } from '../../types';

const T = theme;
interface Props { matchId: string; onComplete: (matchId: string) => void; onBack: () => void; }

type SubStep = 'openers' | 'bowler';

export const SelectOpenersScreen: React.FC<Props> = ({ matchId, onComplete, onBack }) => {
  const match    = db.matches.getById(matchId)!;
  const innings  = db.innings.getByMatch(matchId).find(i => i.inningsNumber === 1)!;

  const battingPlayers = db.players.getByTeam(innings.battingTeamId).filter(p =>
    db.teams.getById(innings.battingTeamId)?.playingXI.includes(p.id)
  );
  const bowlingPlayers = db.players.getByTeam(innings.bowlingTeamId).filter(p =>
    db.teams.getById(innings.bowlingTeamId)?.playingXI.includes(p.id)
  );

  const [subStep, setSubStep]       = useState<SubStep>('openers');
  const [strikerId, setStriker]     = useState<string | null>(null);
  const [nonStrikerId, setNonStriker] = useState<string | null>(null);
  const [bowlerId, setBowler]       = useState<string | null>(null);
  const [confirming, setConfirming] = useState(false);

  const battingTeam = db.teams.getById(innings.battingTeamId)!;
  const bowlingTeam = db.teams.getById(innings.bowlingTeamId)!;

  const handleSelectBatsman = (playerId: string) => {
    if (!strikerId) {
      setStriker(playerId);
    } else if (!nonStrikerId && playerId !== strikerId) {
      setNonStriker(playerId);
    } else if (playerId === strikerId) {
      setStriker(nonStrikerId);
      setNonStriker(null);
    } else if (playerId === nonStrikerId) {
      setNonStriker(null);
    }
  };

  const getBatsmanRole = (id: string): string | null => {
    if (id === strikerId) return 'STRIKER ★';
    if (id === nonStrikerId) return 'NON-STRIKER';
    return null;
  };

  const handleConfirmOpeners = () => {
    if (!strikerId || !nonStrikerId) return;
    setSubStep('bowler');
  };

  const handleConfirmAll = async () => {
    if (!strikerId || !nonStrikerId || !bowlerId) return;
    setConfirming(true);
    await new Promise(r => setTimeout(r, 400));

    // Update innings to ongoing
    db.innings.update(innings.id, { status: 'ongoing' });

    // Update match status to live
    db.matches.update(matchId, { status: 'live' });

    setConfirming(false);
    onComplete(matchId);
  };

  const roleTag = (p: Player) => {
    const roles = p.assignedRoles;
    if (roles.includes('captain')) return 'C';
    if (roles.includes('vice-captain')) return 'VC';
    if (roles.includes('wicketkeeper')) return 'WK';
    return null;
  };

  return (
    <View style={s.screen}>
      <StatusBar barStyle="light-content" />

      <View style={s.header}>
        <TouchableOpacity onPress={subStep === 'openers' ? onBack : () => setSubStep('openers')} style={s.backBtn}>
          <Text style={s.backText}>‹</Text>
        </TouchableOpacity>
        <View style={s.headerCenter}>
          <Text style={s.headerTitle}>
            {subStep === 'openers' ? 'Select Openers' : 'Select Opening Bowler'}
          </Text>
          <Text style={s.headerSub}>
            {subStep === 'openers' ? `${battingTeam.name} batting` : `${bowlingTeam.name} bowling`}
          </Text>
        </View>
        <View style={{ width: 40 }} />
      </View>

      {/* Step indicator */}
      <View style={s.stepBar}>
        <View style={[s.stepSegment, s.stepDone]}>
          <Text style={s.stepSegText}>1 Toss ✓</Text>
        </View>
        <View style={[s.stepSegment, subStep === 'openers' && s.stepActive, subStep === 'bowler' && s.stepDone]}>
          <Text style={s.stepSegText}>2 Openers {subStep === 'bowler' ? '✓' : ''}</Text>
        </View>
        <View style={[s.stepSegment, subStep === 'bowler' && s.stepActive]}>
          <Text style={s.stepSegText}>3 Bowler</Text>
        </View>
      </View>

      {/* ── OPENERS SELECTION ── */}
      {subStep === 'openers' && (
        <View style={s.flex}>
          <View style={s.instrRow}>
            <Text style={s.instrText}>Tap to select. First tap = Striker, Second tap = Non-striker.</Text>
          </View>

          {/* Selection summary */}
          <View style={s.selectionBar}>
            <View style={[s.selSlot, strikerId && s.selSlotFilled]}>
              <Text style={s.selSlotLabel}>STRIKER</Text>
              <Text style={[s.selSlotName, strikerId && s.selSlotNameFilled]}>
                {strikerId ? battingPlayers.find(p => p.id === strikerId)?.name : '— Select —'}
              </Text>
            </View>
            <Text style={s.selDivider}>★</Text>
            <View style={[s.selSlot, { alignItems: 'flex-end' }, nonStrikerId && s.selSlotFilled]}>
              <Text style={s.selSlotLabel}>NON-STRIKER</Text>
              <Text style={[s.selSlotName, nonStrikerId && s.selSlotNameFilled]}>
                {nonStrikerId ? battingPlayers.find(p => p.id === nonStrikerId)?.name : '— Select —'}
              </Text>
            </View>
          </View>

          <FlatList
            data={battingPlayers}
            keyExtractor={p => p.id}
            contentContainerStyle={s.list}
            renderItem={({ item: p }) => {
              const role = getBatsmanRole(p.id);
              const isSelected = p.id === strikerId || p.id === nonStrikerId;
              const tag = roleTag(p);
              return (
                <TouchableOpacity
                  style={[s.playerRow, isSelected && (p.id === strikerId ? s.playerStrikerActive : s.playerNonStrikerActive)]}
                  onPress={() => handleSelectBatsman(p.id)}
                  activeOpacity={0.75}
                >
                  <View style={s.jerseyBadge}>
                    <Text style={s.jerseyNum}>{p.jerseyNumber}</Text>
                  </View>
                  <View style={s.playerInfo}>
                    <View style={s.playerNameRow}>
                      <Text style={[s.playerName, isSelected && s.playerNameActive]}>{p.name}</Text>
                      {tag && <View style={s.roleTag}><Text style={s.roleTagText}>{tag}</Text></View>}
                    </View>
                    <Text style={s.playerMeta}>
                      {p.battingStyle} · {p.primaryRole}
                    </Text>
                  </View>
                  {role && (
                    <View style={[s.roleBadge, p.id === strikerId ? s.strikerBadge : s.nonStrikerBadge]}>
                      <Text style={s.roleBadgeText}>{role}</Text>
                    </View>
                  )}
                </TouchableOpacity>
              );
            }}
          />

          <View style={s.footer}>
            <TouchableOpacity
              style={[s.actionBtn, (!strikerId || !nonStrikerId) && s.actionBtnDisabled]}
              onPress={handleConfirmOpeners}
              disabled={!strikerId || !nonStrikerId}
            >
              <Text style={s.actionBtnText}>Select Opening Bowler →</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* ── BOWLER SELECTION ── */}
      {subStep === 'bowler' && (
        <View style={s.flex}>
          <View style={s.instrRow}>
            <Text style={s.instrText}>Select the player who will bowl the first over.</Text>
          </View>

          <FlatList
            data={bowlingPlayers}
            keyExtractor={p => p.id}
            contentContainerStyle={s.list}
            renderItem={({ item: p }) => {
              const isSelected = p.id === bowlerId;
              const tag = roleTag(p);
              const canBowl = p.bowlingStyle !== 'none';
              return (
                <TouchableOpacity
                  style={[s.playerRow, isSelected && s.playerBowlerActive, !canBowl && s.playerRowDim]}
                  onPress={() => canBowl && setBowler(p.id)}
                  activeOpacity={canBowl ? 0.75 : 1}
                >
                  <View style={s.jerseyBadge}>
                    <Text style={s.jerseyNum}>{p.jerseyNumber}</Text>
                  </View>
                  <View style={s.playerInfo}>
                    <View style={s.playerNameRow}>
                      <Text style={[s.playerName, isSelected && s.playerNameActive]}>{p.name}</Text>
                      {tag && <View style={s.roleTag}><Text style={s.roleTagText}>{tag}</Text></View>}
                    </View>
                    <Text style={s.playerMeta}>
                      {p.bowlingStyle !== 'none' ? p.bowlingStyle : 'Does not bowl'} · {p.primaryRole}
                    </Text>
                  </View>
                  {isSelected && (
                    <View style={s.bowlerSelectedBadge}>
                      <Text style={s.bowlerSelectedText}>OPENING ✓</Text>
                    </View>
                  )}
                  {!canBowl && <Text style={s.cannotBowl}>N/A</Text>}
                </TouchableOpacity>
              );
            }}
          />

          <View style={s.footer}>
            <TouchableOpacity
              style={[s.actionBtn, s.actionBtnGreen, (!bowlerId || confirming) && s.actionBtnDisabled]}
              onPress={handleConfirmAll}
              disabled={!bowlerId || confirming}
            >
              <Text style={s.actionBtnText}>
                {confirming ? 'Starting Match...' : 'Start Match — Begin Scoring →'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
};

const s = StyleSheet.create({
  screen:               { flex: 1, backgroundColor: T.colors.bg },
  flex:                 { flex: 1 },
  header:               { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: T.colors.border },
  backBtn:              { width: 40 },
  backText:             { fontSize: 22, color: T.colors.gold, fontWeight: '600' },
  headerCenter:         { flex: 1, alignItems: 'center' },
  headerTitle:          { fontSize: 18, fontWeight: '800', color: T.colors.text },
  headerSub:            { fontSize: 11, color: T.colors.textMuted, marginTop: 2 },
  stepBar:              { flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 10, gap: 6, borderBottomWidth: 1, borderBottomColor: T.colors.borderLight },
  stepSegment:          { flex: 1, paddingVertical: 6, borderRadius: T.radius.sm, backgroundColor: T.colors.bgElevated, alignItems: 'center' },
  stepActive:           { backgroundColor: T.colors.goldBg, borderWidth: 1, borderColor: T.colors.gold },
  stepDone:             { backgroundColor: T.colors.emeraldBg, borderWidth: 1, borderColor: T.colors.emerald },
  stepSegText:          { fontSize: 10, fontWeight: '700', color: T.colors.textMuted },
  instrRow:             { paddingHorizontal: 16, paddingVertical: 12, backgroundColor: T.colors.bgElevated },
  instrText:            { fontSize: 12, color: T.colors.textMuted, textAlign: 'center' },
  selectionBar:         { flexDirection: 'row', alignItems: 'center', padding: 14, backgroundColor: T.colors.bgCard, borderBottomWidth: 1, borderBottomColor: T.colors.border },
  selSlot:              { flex: 1 },
  selSlotFilled:        {},
  selSlotLabel:         { fontSize: 9, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 1.5, marginBottom: 4 },
  selSlotName:          { fontSize: 13, fontWeight: '600', color: T.colors.textMuted },
  selSlotNameFilled:    { color: T.colors.text, fontWeight: '700' },
  selDivider:           { fontSize: 16, color: T.colors.gold, paddingHorizontal: 14 },
  list:                 { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 100 },
  playerRow:            { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: T.radius.lg, borderWidth: 1, borderColor: T.colors.border, backgroundColor: T.colors.bgCard, marginBottom: 8, ...T.shadow.sm },
  playerStrikerActive:  { borderColor: T.colors.gold, backgroundColor: T.colors.goldBg },
  playerNonStrikerActive:{ borderColor: T.colors.blue, backgroundColor: T.colors.blueBg },
  playerBowlerActive:   { borderColor: T.colors.red, backgroundColor: T.colors.redBg },
  playerRowDim:         { opacity: 0.4 },
  jerseyBadge:          { width: 36, height: 36, borderRadius: 18, backgroundColor: T.colors.bgElevated, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  jerseyNum:            { fontSize: 13, fontWeight: '800', color: T.colors.textSub },
  playerInfo:           { flex: 1 },
  playerNameRow:        { flexDirection: 'row', alignItems: 'center', gap: 6 },
  playerName:           { fontSize: 14, fontWeight: '700', color: T.colors.textSub },
  playerNameActive:     { color: T.colors.text },
  roleTag:              { paddingHorizontal: 6, paddingVertical: 2, backgroundColor: T.colors.bgElevated, borderRadius: T.radius.sm },
  roleTagText:          { fontSize: 9, fontWeight: '800', color: T.colors.gold, letterSpacing: 1 },
  playerMeta:           { fontSize: 11, color: T.colors.textMuted, marginTop: 2, textTransform: 'capitalize' },
  roleBadge:            { paddingHorizontal: 8, paddingVertical: 3, borderRadius: T.radius.full },
  strikerBadge:         { backgroundColor: T.colors.goldBg },
  nonStrikerBadge:      { backgroundColor: T.colors.blueBg },
  roleBadgeText:        { fontSize: 9, fontWeight: '800', color: T.colors.gold, letterSpacing: 0.5 },
  bowlerSelectedBadge:  { backgroundColor: T.colors.redBg, paddingHorizontal: 8, paddingVertical: 3, borderRadius: T.radius.full },
  bowlerSelectedText:   { fontSize: 9, fontWeight: '800', color: T.colors.red, letterSpacing: 0.5 },
  cannotBowl:           { fontSize: 11, color: T.colors.textMuted },
  footer:               { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 20, backgroundColor: T.colors.bg, borderTopWidth: 1, borderTopColor: T.colors.border },
  actionBtn:            { backgroundColor: T.colors.gold, padding: 16, borderRadius: T.radius.xl, alignItems: 'center', ...T.shadow.gold },
  actionBtnGreen:       { backgroundColor: T.colors.emerald },
  actionBtnDisabled:    { backgroundColor: T.colors.bgElevated, shadowOpacity: 0 },
  actionBtnText:        { fontSize: 15, fontWeight: '800', color: T.colors.bg },
});
