// Cricket A7 — Token Entry Screen | Fixed Logic | Asif Lashari | A7 Studio
// FIXES:
//   - Token validated against match directly (no separate tokens collection)
//   - Auto-advance to toss after validation
//   - Match status updated to toss_pending
//   - Shows match info before confirming
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  ScrollView, StatusBar, KeyboardAvoidingView, Platform,
} from 'react-native';
import { theme } from '../../theme';
import { db } from '../../data/db';
import { Match } from '../../types';

const T = theme;
interface Props { onSuccess: (matchId: string) => void; onBack: () => void; }

export const TokenEntryScreen: React.FC<Props> = ({ onSuccess, onBack }) => {
  const [token, setToken]         = useState('');
  const [foundMatch, setFound]    = useState<Match | null>(null);
  const [error, setError]         = useState<string | null>(null);
  const [loading, setLoading]     = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  const user = db.auth.getCurrentUser()!;

  const handleLookup = () => {
    if (token.trim().length < 3) { setError('Enter a valid token'); return; }
    setError(null);
    const cleaned = token.trim().toUpperCase();

    // Search all matches for this token
    const allMatches = db.matches.getAll();
    const match = allMatches.find(m =>
      m.scorerToken === cleaned &&
      m.status === 'scheduled'
    );

    if (!match) {
      setError('Token not found or match already started. Contact the organizer.');
      setFound(null);
      return;
    }

    setFound(match);
  };

  const handleConfirm = async () => {
    if (!foundMatch) return;
    setLoading(true);
    await new Promise(r => setTimeout(r, 500));
    // Activate scorer
    db.matches.activateScorer(foundMatch.id, user.id);
    setLoading(false);
    onSuccess(foundMatch.id);
  };

  const team1 = foundMatch ? db.teams.getById(foundMatch.team1Id) : null;
  const team2 = foundMatch ? db.teams.getById(foundMatch.team2Id) : null;
  const tournament = foundMatch?.tournamentId ? db.tournaments.getById(foundMatch.tournamentId) : null;

  const formatDate = (ts: number) => new Date(ts).toLocaleString('en-PK', { dateStyle: 'medium', timeStyle: 'short' });

  return (
    <KeyboardAvoidingView style={s.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <StatusBar barStyle="light-content" />

      <View style={s.header}>
        <TouchableOpacity onPress={onBack} style={s.backBtn}>
          <Text style={s.backText}>‹</Text>
        </TouchableOpacity>
        <Text style={s.headerTitle}>Scorer Access</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">

        <View style={s.heroWrap}>
          <View style={s.keyIcon}><Text style={s.keyEmoji}>🔑</Text></View>
          <Text style={s.heroTitle}>Enter Scorer Token</Text>
          <Text style={s.heroSub}>
            Enter the token your organizer sent you to unlock live scoring for your match.
          </Text>
        </View>

        {/* Token input */}
        <Text style={s.fieldLabel}>TOKEN</Text>
        <View style={s.tokenInputRow}>
          <TextInput
            style={s.tokenInput}
            value={token}
            onChangeText={v => { setToken(v.toUpperCase()); setError(null); setFound(null); }}
            placeholder="e.g. A7-XKQP7M2R"
            placeholderTextColor={T.colors.textMuted}
            autoCapitalize="characters"
            autoCorrect={false}
            autoFocus
          />
          <TouchableOpacity
            style={[s.lookupBtn, !token && s.lookupBtnDisabled]}
            onPress={handleLookup}
            disabled={!token}
          >
            <Text style={s.lookupBtnText}>Find Match</Text>
          </TouchableOpacity>
        </View>

        {error && (
          <View style={s.errorBox}>
            <Text style={s.errorText}>⚠ {error}</Text>
          </View>
        )}

        {/* Found match preview */}
        {foundMatch && (
          <View style={s.matchPreview}>
            <View style={s.matchPreviewHeader}>
              <View style={s.foundBadge}>
                <Text style={s.foundBadgeText}>✓ MATCH FOUND</Text>
              </View>
              {tournament && <Text style={s.matchTournament}>{tournament.name}</Text>}
            </View>

            <View style={s.matchTeamsRow}>
              <View style={s.matchTeamBlock}>
                <View style={[s.teamColorDot, { backgroundColor: team1?.color || T.colors.gold }]} />
                <Text style={s.matchTeamName}>{team1?.name}</Text>
              </View>
              <Text style={s.matchVs}>VS</Text>
              <View style={[s.matchTeamBlock, { justifyContent: 'flex-end' }]}>
                <Text style={[s.matchTeamName, { textAlign: 'right' }]}>{team2?.name}</Text>
                <View style={[s.teamColorDot, { backgroundColor: team2?.color || T.colors.emerald }]} />
              </View>
            </View>

            <View style={s.matchDetails}>
              <View style={s.matchDetailItem}>
                <Text style={s.matchDetailLabel}>VENUE</Text>
                <Text style={s.matchDetailValue}>{foundMatch.venue}</Text>
              </View>
              <View style={s.matchDetailItem}>
                <Text style={s.matchDetailLabel}>FORMAT</Text>
                <Text style={s.matchDetailValue}>{foundMatch.format} · {foundMatch.totalOvers} ov</Text>
              </View>
              <View style={s.matchDetailItem}>
                <Text style={s.matchDetailLabel}>SCHEDULED</Text>
                <Text style={s.matchDetailValue}>{formatDate(foundMatch.scheduledAt)}</Text>
              </View>
            </View>

            {/* XI check */}
            {(() => {
              const t1 = db.teams.getById(foundMatch.team1Id);
              const t2 = db.teams.getById(foundMatch.team2Id);
              const t1Ready = t1?.isXILocked && t1.playingXI.length === 11;
              const t2Ready = t2?.isXILocked && t2.playingXI.length === 11;
              return (!t1Ready || !t2Ready) ? (
                <View style={s.xiWarning}>
                  <Text style={s.xiWarningText}>
                    ⚠ {!t1Ready && team1?.name} {!t1Ready && !t2Ready ? ' and ' : ''} {!t2Ready && team2?.name}{' '}
                    {!t1Ready && !t2Ready ? 'have' : 'has'} not locked Playing XI.{'\n'}
                    Scoring can be activated but toss must wait until XI is locked.
                  </Text>
                </View>
              ) : null;
            })()}

            <TouchableOpacity
              style={[s.confirmBtn, loading && s.confirmBtnDisabled]}
              onPress={handleConfirm}
              disabled={loading}
            >
              <Text style={s.confirmBtnText}>
                {loading ? 'Activating...' : 'Confirm & Proceed to Toss →'}
              </Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={s.hint}>
          <Text style={s.hintText}>
            Don't have a token? Ask your tournament organizer to generate one from their Token Generator screen.
          </Text>
        </View>

      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const s = StyleSheet.create({
  screen:            { flex: 1, backgroundColor: T.colors.bg },
  header:            { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: T.colors.border },
  backBtn:           { width: 40 },
  backText:          { fontSize: 22, color: T.colors.gold, fontWeight: '600' },
  headerTitle:       { flex: 1, textAlign: 'center', fontSize: 18, fontWeight: '800', color: T.colors.text },
  content:           { padding: 24, paddingBottom: 60 },
  heroWrap:          { alignItems: 'center', paddingVertical: 28 },
  keyIcon:           { width: 72, height: 72, borderRadius: 36, backgroundColor: T.colors.goldBg, alignItems: 'center', justifyContent: 'center', marginBottom: 16, borderWidth: 1, borderColor: T.colors.border, ...T.shadow.gold },
  keyEmoji:          { fontSize: 34 },
  heroTitle:         { fontSize: 22, fontWeight: '800', color: T.colors.text, marginBottom: 8 },
  heroSub:           { fontSize: 13, color: T.colors.textMuted, textAlign: 'center', lineHeight: 20, maxWidth: 280 },
  fieldLabel:        { fontSize: 10, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 2, marginBottom: 10 },
  tokenInputRow:     { flexDirection: 'row', gap: 10, marginBottom: 12 },
  tokenInput:        { flex: 1, backgroundColor: T.colors.bgInput, borderRadius: T.radius.md, borderWidth: 1, borderColor: T.colors.border, color: T.colors.text, padding: 14, fontSize: 16, fontWeight: '700', letterSpacing: 2 },
  lookupBtn:         { paddingHorizontal: 16, paddingVertical: 14, backgroundColor: T.colors.gold, borderRadius: T.radius.md, justifyContent: 'center', ...T.shadow.gold },
  lookupBtnDisabled: { backgroundColor: T.colors.bgElevated, shadowOpacity: 0 },
  lookupBtnText:     { fontSize: 13, fontWeight: '800', color: T.colors.bg },
  errorBox:          { padding: 12, backgroundColor: T.colors.redBg, borderRadius: T.radius.md, borderWidth: 1, borderColor: T.colors.red + '44', marginBottom: 16 },
  errorText:         { fontSize: 13, color: T.colors.red, fontWeight: '600' },
  matchPreview:      { backgroundColor: T.colors.bgCard, borderRadius: T.radius.xl, borderWidth: 1, borderColor: T.colors.emerald + '44', padding: 18, marginBottom: 20 },
  matchPreviewHeader:{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  foundBadge:        { paddingHorizontal: 10, paddingVertical: 4, backgroundColor: T.colors.emeraldBg, borderRadius: T.radius.full },
  foundBadgeText:    { fontSize: 9, fontWeight: '800', color: T.colors.emerald, letterSpacing: 1.5 },
  matchTournament:   { fontSize: 11, color: T.colors.textMuted },
  matchTeamsRow:     { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 },
  matchTeamBlock:    { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
  teamColorDot:      { width: 10, height: 10, borderRadius: 5, flexShrink: 0 },
  matchTeamName:     { fontSize: 15, fontWeight: '700', color: T.colors.text, flex: 1 },
  matchVs:           { fontSize: 11, fontWeight: '700', color: T.colors.textMuted, paddingHorizontal: 8 },
  matchDetails:      { gap: 10, borderTopWidth: 1, borderTopColor: T.colors.borderLight, paddingTop: 14, marginBottom: 14 },
  matchDetailItem:   { flexDirection: 'row', justifyContent: 'space-between' },
  matchDetailLabel:  { fontSize: 10, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 1 },
  matchDetailValue:  { fontSize: 12, color: T.colors.textSub, fontWeight: '600' },
  xiWarning:         { backgroundColor: T.colors.orangeBg, borderRadius: T.radius.md, padding: 10, marginBottom: 14 },
  xiWarningText:     { fontSize: 11, color: T.colors.orange, lineHeight: 16 },
  confirmBtn:        { backgroundColor: T.colors.emerald, padding: 16, borderRadius: T.radius.lg, alignItems: 'center', ...T.shadow.md },
  confirmBtnDisabled:{ opacity: 0.5 },
  confirmBtnText:    { fontSize: 15, fontWeight: '800', color: T.colors.bg },
  hint:              { padding: 16, backgroundColor: T.colors.bgElevated, borderRadius: T.radius.md },
  hintText:          { fontSize: 12, color: T.colors.textMuted, textAlign: 'center', lineHeight: 18 },
});
