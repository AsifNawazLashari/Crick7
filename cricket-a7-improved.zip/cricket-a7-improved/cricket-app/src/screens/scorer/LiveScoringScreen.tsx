// Cricket A7 — Live Scoring Screen | Complete Rewrite | Asif Lashari | A7 Studio
// FIXES:
//   - Striker/non-striker pulled from liveState, not first two players of team
//   - Free Hit tracked and displayed — restricts dismissal options
//   - Legal ball counter separate from raw delivery sequence
//   - Wicket dismissal validation per ICC rules
//   - Auto-rotate strike on odd runs, end of over
//   - Undo last ball within current over (free), previous over needs reason
//   - New batsman prompt after wicket
//   - New bowler prompt after over complete
//   - Powerplay auto-detection with banner
//   - Commentary auto-generated with variation bank
import React, { useState, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Modal, TextInput, Alert, StatusBar, Vibration,
} from 'react-native';
import { theme } from '../../theme';
import { db } from '../../data/db';
import {
  isLegalDelivery, isDismissalValidOnDelivery, computeNextIsFreeHit,
  computeTotalRunsFromDelivery, getActivePowerplay, formatOvers,
  computeCRR, computeRRR, shouldInningsEnd, getCommentary,
} from '../../logic/scoringEngine';
import { WicketType, ExtraType, Delivery, Player } from '../../types';

const T = theme;
interface Props { matchId: string; onInningsEnd: (matchId: string) => void; onBack: () => void; }

type RunOption = 0 | 1 | 2 | 3 | 4 | 6;
const RUN_OPTIONS: RunOption[] = [0, 1, 2, 3, 4, 6];
const WICKET_TYPES: WicketType[] = ['bowled','caught','lbw','run-out','stumped','hit-wicket','obstructing'];

// ─────────────────────────────────────────────────────────────────────────────
export const LiveScoringScreen: React.FC<Props> = ({ matchId, onInningsEnd, onBack }) => {
  const match   = db.matches.getById(matchId)!;
  const innings = db.innings.getByMatch(matchId).find(i => i.status === 'ongoing')!;

  if (!innings) {
    return (
      <View style={s.screen}>
        <View style={s.center}>
          <Text style={s.noMatchText}>No active innings found.</Text>
          <TouchableOpacity style={s.backLink} onPress={onBack}><Text style={s.backLinkText}>Go Back</Text></TouchableOpacity>
        </View>
      </View>
    );
  }

  const battingTeam  = db.teams.getById(innings.battingTeamId)!;
  const bowlingTeam  = db.teams.getById(innings.bowlingTeamId)!;
  const battingXI    = battingTeam.playingXI.map(id => db.players.getById(id)!).filter(Boolean);
  const bowlingXI    = bowlingTeam.playingXI.map(id => db.players.getById(id)!).filter(Boolean);

  // ── Live state ────────────────────────────────────────────────────────────
  const allDeliveries = db.deliveries.getByInnings(innings.id);

  // Derive live batsmen from delivery history
  const deriveLiveBatsmen = useCallback(() => {
    const dismissed = new Set(allDeliveries.filter(d => d.isWicket).map(d => d.dismissedId));
    const batted    = allDeliveries.map(d => d.batsmanId);
    const nonSt     = allDeliveries.map(d => d.nonStrikerId);
    const lastDel   = allDeliveries[allDeliveries.length - 1];

    // Current batsmen are last seen striker + non-striker who aren't dismissed
    const activeBatsmen = [...new Set([...batted, ...nonSt])].filter(id => !dismissed.has(id));
    const lastStriker   = lastDel ? (lastDel.isLegal && [1,3,5].includes(lastDel.runsOffBat) ? lastDel.nonStrikerId : lastDel.batsmanId) : battingXI[0]?.id;
    const striker       = activeBatsmen.includes(lastStriker) ? lastStriker : activeBatsmen[0];
    const nonStriker    = activeBatsmen.find(id => id !== striker) || '';
    return { strikerId: striker || battingXI[0]?.id || '', nonStrikerId: nonStriker || battingXI[1]?.id || '' };
  }, [allDeliveries, battingXI]);

  const deriveCurrentBowler = useCallback(() => {
    const lastLegal = [...allDeliveries].reverse().find(d => d.isLegal);
    return lastLegal?.bowlerId || bowlingXI[0]?.id || '';
  }, [allDeliveries, bowlingXI]);

  const [strikerId, setStriker]     = useState(() => deriveLiveBatsmen().strikerId);
  const [nonStrikerId, setNonStriker] = useState(() => deriveLiveBatsmen().nonStrikerId);
  const [bowlerId, setBowler]       = useState(() => deriveCurrentBowler());
  const [isFreeHit, setFreeHit]     = useState(false);

  // Ball input state
  const [runs, setRuns]             = useState<RunOption | null>(null);
  const [extraType, setExtraType]   = useState<ExtraType | null>(null);
  const [extraRuns, setExtraRuns]   = useState(0);
  const [isWicket, setIsWicket]     = useState(false);
  const [wicketType, setWicketType] = useState<WicketType | null>(null);
  const [dismissedId, setDismissed] = useState<string | null>(null);
  const [fielderId, setFielder]     = useState<string | null>(null);

  // Modals
  const [showWicketModal, setWicketModal]   = useState(false);
  const [showNewBatsman, setNewBatsman]     = useState(false);
  const [showNewBowler, setNewBowler]       = useState(false);
  const [showUndoModal, setUndoModal]       = useState(false);
  const [showBBB, setBBB]                   = useState(false);
  const [undoReason, setUndoReason]         = useState('');

  // Compute from deliveries
  const currentOverBalls = allDeliveries.filter(d => d.overNumber === Math.floor(innings.legalBalls / 6) + 1);
  const overNumber       = Math.floor(innings.legalBalls / 6) + 1;
  const ballsInOver      = innings.legalBalls % 6;
  const ppStatus         = getActivePowerplay(overNumber, match.powerplays);

  // Batsman live stats
  const getBatsmanStats = (pid: string) => {
    const dels = allDeliveries.filter(d => d.batsmanId === pid);
    return {
      runs: dels.reduce((a, d) => a + (d.extraType === 'bye' || d.extraType === 'leg-bye' ? 0 : d.runsOffBat), 0),
      balls: dels.filter(d => d.isLegal).length,
      fours: dels.filter(d => d.boundaryType === '4').length,
      sixes: dels.filter(d => d.boundaryType === '6').length,
    };
  };

  // Bowler live stats
  const getBowlerStats = (pid: string) => {
    const dels = allDeliveries.filter(d => d.bowlerId === pid);
    const legal = dels.filter(d => d.isLegal).length;
    return {
      overs: formatOvers(legal),
      runs: dels.reduce((a, d) => a + computeTotalRunsFromDelivery(d.runsOffBat, d.extraType, d.extraRuns), 0),
      wickets: dels.filter(d => d.isWicket && d.isBowlerWicket).length,
      wides: dels.filter(d => d.extraType === 'wide').length,
      noBalls: dels.filter(d => d.extraType === 'no-ball').length,
    };
  };

  const strikerPlayer    = db.players.getById(strikerId);
  const nonStrikerPlayer = db.players.getById(nonStrikerId);
  const bowlerPlayer     = db.players.getById(bowlerId);
  const strikerStats     = getBatsmanStats(strikerId);
  const nonStrikerStats  = getBatsmanStats(nonStrikerId);
  const bowlerStats      = getBowlerStats(bowlerId);

  const resetInputs = () => {
    setRuns(null); setExtraType(null); setExtraRuns(0);
    setIsWicket(false); setWicketType(null); setDismissed(null); setFielder(null);
  };

  // ── DELIVER ──────────────────────────────────────────────────────────────
  const handleDeliver = useCallback(() => {
    const runsOffBat    = runs ?? 0;
    const isLegal       = isLegalDelivery(extraType);
    const totalRuns     = computeTotalRunsFromDelivery(runsOffBat, extraType, extraRuns);
    const nextFreeHit   = computeNextIsFreeHit(extraType);

    // Validate wicket
    if (isWicket && wicketType) {
      const validation = isDismissalValidOnDelivery(wicketType, isFreeHit, extraType);
      if (!validation.valid) {
        Alert.alert('Invalid Dismissal', validation.reason);
        return;
      }
    }

    // Dismissed player: default to striker unless run-out where dismissedId is set
    const actualDismissedId = isWicket
      ? (wicketType === 'run-out' && dismissedId ? dismissedId : strikerId)
      : null;

    const isBowlerW = isWicket && wicketType ? !['run-out','obstructing','timed-out','retired-out'].includes(wicketType) : false;

    const delivery: Omit<Delivery, 'id'> = {
      inningsId: innings.id,
      matchId,
      overNumber,
      ballInOver: isLegal ? ballsInOver + 1 : ballsInOver,
      rawSequence: currentOverBalls.length + 1,
      batsmanId: strikerId,
      bowlerId,
      nonStrikerId,
      runsOffBat,
      isLegal,
      extraType,
      extraRuns,
      isFreeHit,
      nextIsFreeHit: nextFreeHit,
      isWicket: !!isWicket,
      wicketType: isWicket ? wicketType : null,
      dismissedId: actualDismissedId,
      fielderId: fielderId || null,
      isBowlerWicket: isBowlerW,
      isBoundary: runsOffBat === 4 || runsOffBat === 6,
      boundaryType: runsOffBat === 4 ? '4' : runsOffBat === 6 ? '6' : null,
      shotZone: null,
      isPowerplay: ppStatus.active,
      timestamp: Date.now(),
    };

    db.deliveries.add(delivery);

    // Vibrate on wicket/six
    if (isWicket || runsOffBat === 6) Vibration.vibrate(100);

    // Update innings counters
    const newLegalBalls = innings.legalBalls + (isLegal ? 1 : 0);
    const newWickets    = innings.wickets + (isWicket ? 1 : 0);
    const newRuns       = innings.totalRuns + totalRuns;
    const newExtras     = {
      ...innings.extras,
      wides:   innings.extras.wides   + (extraType === 'wide'    ? 1 + extraRuns : 0),
      noBalls: innings.extras.noBalls + (extraType === 'no-ball' ? 1             : 0),
      byes:    innings.extras.byes    + (extraType === 'bye'     ? extraRuns     : 0),
      legByes: innings.extras.legByes + (extraType === 'leg-bye' ? extraRuns     : 0),
    };

    db.innings.update(innings.id, {
      totalRuns: newRuns,
      wickets: newWickets,
      legalBalls: newLegalBalls,
      extras: newExtras,
    });

    // Auto commentary
    const striker = db.players.getById(strikerId);
    const bowler  = db.players.getById(bowlerId);
    db.commentary.add({
      deliveryId: null,
      matchId,
      overNumber,
      ballInOver: isLegal ? ballsInOver + 1 : ballsInOver,
      text: getCommentary({
        runsOffBat, extraType,
        isWicket: !!isWicket, wicketType: isWicket ? wicketType : null,
        isFreeHit,
        batsmanName: striker?.name || 'Batsman',
        bowlerName: bowler?.name || 'Bowler',
      }),
      type: isWicket ? 'wicket' : runsOffBat === 6 ? 'six' : runsOffBat === 4 ? 'four' : extraType === 'wide' ? 'wide' : extraType === 'no-ball' ? 'no-ball' : 'normal',
      isCustom: false,
      addedBy: db.auth.getCurrentUser()?.id || '',
      timestamp: Date.now(),
    });

    // Update free hit state
    setFreeHit(nextFreeHit);

    // Check innings end
    const endCheck = shouldInningsEnd(newWickets, newLegalBalls, match.totalOvers, innings.maxWickets, newRuns, innings.target);
    if (endCheck.end) {
      db.innings.update(innings.id, { status: 'completed', totalRuns: newRuns, wickets: newWickets, legalBalls: newLegalBalls });
      db.matches.update(matchId, { status: 'innings_break' });
      onInningsEnd(matchId);
      return;
    }

    // Over complete?
    const overComplete = isLegal && (newLegalBalls % 6 === 0);

    // Strike rotation
    if (isLegal) {
      const shouldRotate = [1, 3, 5].includes(runsOffBat) || overComplete;
      if (shouldRotate) {
        setStriker(nonStrikerId);
        setNonStriker(strikerId);
      }
    }

    // After wicket: prompt new batsman
    if (isWicket) {
      setNewBatsman(true);
    }

    // After over: prompt new bowler
    if (overComplete && !isWicket) {
      setNewBowler(true);
    }

    resetInputs();
  }, [runs, extraType, extraRuns, isWicket, wicketType, dismissedId, fielderId, strikerId, nonStrikerId, bowlerId, innings, matchId, isFreeHit, overNumber, ballsInOver]);

  // ── UNDO ─────────────────────────────────────────────────────────────────
  const handleUndo = () => {
    const lastDel = [...allDeliveries].pop();
    if (!lastDel) return;
    const isCurrentOver = lastDel.overNumber === overNumber;
    if (isCurrentOver) {
      // Free undo within current over
      performUndo();
    } else {
      // Need reason for previous over undo
      setUndoModal(true);
    }
  };

  const performUndo = () => {
    const removed = db.deliveries.undoLast(innings.id);
    if (!removed) return;
    const totalRuns = computeTotalRunsFromDelivery(removed.runsOffBat, removed.extraType, removed.extraRuns);
    db.innings.update(innings.id, {
      totalRuns: innings.totalRuns - totalRuns,
      wickets: innings.wickets - (removed.isWicket ? 1 : 0),
      legalBalls: innings.legalBalls - (removed.isLegal ? 1 : 0),
    });
    // Restore free hit state
    setFreeHit(removed.isFreeHit);
    setUndoModal(false);
  };

  // ── DELIVER BUTTON LABEL ──────────────────────────────────────────────────
  const getDeliverLabel = () => {
    if (isWicket && wicketType) return `WICKET — ${wicketType.toUpperCase()}`;
    if (extraType === 'wide')    return 'WIDE + ' + (extraRuns > 0 ? extraRuns : 0) + ' runs';
    if (extraType === 'no-ball') return 'NO BALL' + (isFreeHit ? ' (was FREE HIT)' : '') + ' → FREE HIT';
    if (extraType === 'bye')     return `BYE ${extraRuns} run${extraRuns !== 1 ? 's' : ''}`;
    if (extraType === 'leg-bye') return `LEG BYE ${extraRuns} run${extraRuns !== 1 ? 's' : ''}`;
    if (runs !== null)           return `DELIVER ${runs === 0 ? 'DOT' : runs} ${runs === 4 ? '— FOUR!' : runs === 6 ? '— SIX!' : runs === 1 ? 'run' : 'runs'}`;
    return 'Select runs or extra';
  };

  const canDeliver = runs !== null || extraType !== null;

  // ── DOT TRACKER ───────────────────────────────────────────────────────────
  const getDotColor = (d: Delivery) => {
    if (d.isWicket)                  return T.colors.score.wicket;
    if (d.boundaryType === '6')      return T.colors.score.six;
    if (d.boundaryType === '4')      return T.colors.score.four;
    if (d.extraType === 'wide')      return T.colors.score.wide;
    if (d.extraType === 'no-ball')   return T.colors.score.noBall;
    if (d.extraType === 'bye' || d.extraType === 'leg-bye') return T.colors.score.triple;
    if (d.runsOffBat === 0)          return T.colors.score.dot;
    if (d.runsOffBat === 1)          return T.colors.score.single;
    if (d.runsOffBat === 2)          return T.colors.score.double;
    return T.colors.score.triple;
  };

  const getDotLabel = (d: Delivery) => {
    if (d.isWicket)                return 'W';
    if (d.extraType === 'wide')    return 'Wd';
    if (d.extraType === 'no-ball') return 'NB';
    if (d.extraType === 'bye')     return 'B';
    if (d.extraType === 'leg-bye') return 'LB';
    return String(d.runsOffBat);
  };

  return (
    <View style={s.screen}>
      <StatusBar barStyle="light-content" />

      {/* ── SCOREBOARD ── */}
      <View style={s.scoreboard}>
        {isFreeHit && (
          <View style={s.freeHitBanner}>
            <Text style={s.freeHitText}>⚡ FREE HIT — Batsman safe from most dismissals</Text>
          </View>
        )}
        {ppStatus.active && (
          <View style={s.ppBanner}>
            <Text style={s.ppText}>⚡ {ppStatus.label} — POWERPLAY ACTIVE</Text>
          </View>
        )}

        <View style={s.scoreMain}>
          <View style={s.scoreLeft}>
            <Text style={s.teamNameScore}>{battingTeam.name}</Text>
            <Text style={s.scoreRuns}>{innings.totalRuns}<Text style={s.scoreWickets}>/{innings.wickets}</Text></Text>
            <Text style={s.scoreOvers}>
              {formatOvers(innings.legalBalls)} ov · CRR {computeCRR(innings.totalRuns, innings.legalBalls)}
            </Text>
          </View>
          {innings.target && (
            <View style={s.targetBlock}>
              <Text style={s.targetLabel}>TARGET</Text>
              <Text style={s.targetValue}>{innings.target}</Text>
              <Text style={s.targetNeed}>
                Need {innings.target - innings.totalRuns} off {(match.totalOvers * 6) - innings.legalBalls} balls
              </Text>
              <Text style={s.rrr}>RRR {computeRRR(innings.target, innings.totalRuns, match.totalOvers, innings.legalBalls)}</Text>
            </View>
          )}
        </View>

        {/* Dot ball tracker */}
        <View style={s.dotRow}>
          {Array.from({ length: 6 }, (_, i) => {
            const d = currentOverBalls.filter(b => b.isLegal)[i];
            const raw = currentOverBalls[i];
            return (
              <View key={i} style={[s.dot, { backgroundColor: d ? getDotColor(d) : (raw ? getDotColor(raw) : T.colors.bgElevated) }]}>
                <Text style={s.dotLabel}>{d ? getDotLabel(d) : (raw ? getDotLabel(raw) : '·')}</Text>
              </View>
            );
          })}
          <Text style={s.overLabel}>Over {overNumber}</Text>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">

        {/* ── BATSMEN ROW ── */}
        <View style={s.batsmenRow}>
          {[
            { p: strikerPlayer, stats: strikerStats, isStriker: true },
            { p: nonStrikerPlayer, stats: nonStrikerStats, isStriker: false },
          ].map(({ p, stats, isStriker }) => p ? (
            <View key={p.id} style={[s.batsmanCard, isStriker && s.batsmanCardStriker]}>
              {isStriker && <View style={s.strikerStar}><Text style={s.strikerStarText}>★</Text></View>}
              <Text style={s.batsmanRole}>{isStriker ? 'ON STRIKE' : 'NON-STRIKER'}</Text>
              <Text style={s.batsmanName} numberOfLines={1}>{p.name}</Text>
              <Text style={s.batsmanScore}>{stats.runs}<Text style={s.batsmanBalls}> ({stats.balls})</Text></Text>
              <Text style={s.batsmanExtra}>{stats.fours}×4  {stats.sixes}×6</Text>
            </View>
          ) : null)}
        </View>

        {/* ── BOWLER ROW ── */}
        <View style={s.bowlerRow}>
          <View style={s.bowlerLeft}>
            <Text style={s.bowlerLabel}>BOWLING</Text>
            <Text style={s.bowlerName}>{bowlerPlayer?.name || '—'}</Text>
          </View>
          <Text style={s.bowlerFigures}>
            {bowlerStats.overs} ov  {bowlerStats.wickets}/{bowlerStats.runs}  · Wd:{bowlerStats.wides}  NB:{bowlerStats.noBalls}
          </Text>
        </View>

        {/* ── INPUT PANEL ── */}
        <View style={s.panel}>

          {/* Run buttons */}
          <Text style={s.panelSection}>RUNS</Text>
          <View style={s.runGrid}>
            {RUN_OPTIONS.map(r => (
              <TouchableOpacity
                key={r}
                style={[
                  s.runBtn,
                  runs === r && s.runBtnSelected,
                  r === 4 && s.runBtn4,
                  r === 6 && s.runBtn6,
                  runs === r && r === 4 && s.runBtn4Active,
                  runs === r && r === 6 && s.runBtn6Active,
                ]}
                onPress={() => { setRuns(runs === r ? null : r); setExtraType(null); }}
              >
                <Text style={[s.runBtnText, runs === r && s.runBtnTextActive]}>
                  {r === 0 ? '·' : r}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Extras */}
          <Text style={s.panelSection}>EXTRAS</Text>
          <View style={s.extrasGrid}>
            {(['wide','no-ball','bye','leg-bye'] as ExtraType[]).map(et => (
              <TouchableOpacity
                key={et}
                style={[s.extraBtn, extraType === et && s.extraBtnActive]}
                onPress={() => { setExtraType(extraType === et ? null : et); setRuns(null); }}
              >
                <Text style={[s.extraBtnText, extraType === et && s.extraBtnTextActive]}>
                  {et === 'wide' ? 'Wide' : et === 'no-ball' ? 'No Ball' : et === 'bye' ? 'Bye' : 'Leg Bye'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Extra runs input for bye/leg-bye/wide+runs */}
          {(extraType === 'bye' || extraType === 'leg-bye' || extraType === 'wide') && (
            <View style={s.extraRunsRow}>
              <Text style={s.extraRunsLabel}>
                {extraType === 'wide' ? 'Additional runs off wide:' : 'Runs taken:'}
              </Text>
              <View style={s.extraRunsBtns}>
                {[0,1,2,3,4].map(n => (
                  <TouchableOpacity
                    key={n}
                    style={[s.extraRunBtn, extraRuns === n && s.extraRunBtnActive]}
                    onPress={() => setExtraRuns(n)}
                  >
                    <Text style={[s.extraRunBtnText, extraRuns === n && s.extraRunBtnTextActive]}>{n}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}

          {/* Wicket toggle */}
          <TouchableOpacity
            style={[s.wicketToggle, isWicket && s.wicketToggleActive]}
            onPress={() => { setIsWicket(!isWicket); setWicketType(null); if (!isWicket) setWicketModal(true); }}
          >
            <Text style={[s.wicketToggleText, isWicket && s.wicketToggleTextActive]}>
              {isWicket ? `WICKET: ${wicketType?.toUpperCase() || 'Select Type'}` : '+ Mark Wicket'}
            </Text>
          </TouchableOpacity>

          {/* Free Hit warning */}
          {isFreeHit && (
            <View style={s.freeHitNote}>
              <Text style={s.freeHitNoteText}>
                FREE HIT active. Only run-out, obstructing, or hit-wicket dismissals are valid.
              </Text>
            </View>
          )}

          {/* DELIVER button */}
          <TouchableOpacity
            style={[s.deliverBtn, !canDeliver && s.deliverBtnDisabled]}
            onPress={handleDeliver}
            disabled={!canDeliver}
            activeOpacity={0.85}
          >
            <Text style={s.deliverBtnText}>{getDeliverLabel()}</Text>
          </TouchableOpacity>

        </View>

        {/* ── ACTIONS BAR ── */}
        <View style={s.actionsBar}>
          <TouchableOpacity style={s.actionChip} onPress={handleUndo}>
            <Text style={s.actionChipText}>↩ Undo</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.actionChip} onPress={() => setNewBowler(true)}>
            <Text style={s.actionChipText}>Change Bowler</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.actionChip} onPress={() => setBBB(!showBBB)}>
            <Text style={s.actionChipText}>{showBBB ? 'Hide' : 'Ball by Ball'}</Text>
          </TouchableOpacity>
        </View>

        {/* ── BALL BY BALL ── */}
        {showBBB && (
          <View style={s.bbbWrap}>
            <Text style={s.bbbTitle}>BALL BY BALL</Text>
            {[...allDeliveries].reverse().slice(0, 30).map(d => {
              const bat = db.players.getById(d.batsmanId);
              const bowl = db.players.getById(d.bowlerId);
              return (
                <View key={d.id} style={s.bbbRow}>
                  <View style={[s.bbbDot, { backgroundColor: getDotColor(d) }]}>
                    <Text style={s.bbbDotText}>{getDotLabel(d)}</Text>
                  </View>
                  <View style={s.bbbInfo}>
                    <Text style={s.bbbOver}>Ov {d.overNumber}.{d.ballInOver}</Text>
                    <Text style={s.bbbPlayers}>{bat?.name} v {bowl?.name}</Text>
                  </View>
                  <Text style={s.bbbComm} numberOfLines={1}>
                    {db.commentary.getByMatch(matchId).find(c => c.overNumber === d.overNumber && c.ballInOver === d.ballInOver)?.text || ''}
                  </Text>
                </View>
              );
            })}
          </View>
        )}

      </ScrollView>

      {/* ── WICKET TYPE MODAL ── */}
      <Modal visible={showWicketModal} transparent animationType="slide">
        <View style={m.overlay}>
          <View style={m.sheet}>
            <Text style={m.sheetTitle}>Select Dismissal Type</Text>
            {isFreeHit && (
              <View style={m.freeHitWarn}>
                <Text style={m.freeHitWarnText}>FREE HIT active: only run-out, obstructing, hit-wicket valid</Text>
              </View>
            )}
            <View style={m.wicketGrid}>
              {WICKET_TYPES.map(wt => {
                const validation = isDismissalValidOnDelivery(wt, isFreeHit, extraType);
                return (
                  <TouchableOpacity
                    key={wt}
                    style={[m.wicketBtn, wicketType === wt && m.wicketBtnActive, !validation.valid && m.wicketBtnDisabled]}
                    onPress={() => {
                      if (!validation.valid) {
                        Alert.alert('Not valid on Free Hit', validation.reason);
                        return;
                      }
                      setWicketType(wt);
                      setIsWicket(true);
                    }}
                    disabled={!validation.valid}
                  >
                    <Text style={[m.wicketBtnText, wicketType === wt && m.wicketBtnTextActive]}>
                      {wt.replace('-', ' ').toUpperCase()}
                    </Text>
                    {!validation.valid && <Text style={m.wicketInvalidText}>not valid</Text>}
                  </TouchableOpacity>
                );
              })}
            </View>

            {/* Run-out: select who got run out */}
            {wicketType === 'run-out' && (
              <>
                <Text style={m.subLabel}>WHO WAS RUN OUT?</Text>
                {[strikerPlayer, nonStrikerPlayer].filter(Boolean).map(p => p && (
                  <TouchableOpacity
                    key={p.id}
                    style={[m.playerBtn, dismissedId === p.id && m.playerBtnActive]}
                    onPress={() => setDismissed(p.id)}
                  >
                    <Text style={m.playerBtnText}>{p.name}</Text>
                  </TouchableOpacity>
                ))}
              </>
            )}

            {/* Caught: select fielder */}
            {wicketType === 'caught' && (
              <>
                <Text style={m.subLabel}>CAUGHT BY</Text>
                <ScrollView style={{ maxHeight: 150 }}>
                  {bowlingXI.map(p => (
                    <TouchableOpacity
                      key={p.id}
                      style={[m.playerBtn, fielderId === p.id && m.playerBtnActive]}
                      onPress={() => setFielder(p.id)}
                    >
                      <Text style={m.playerBtnText}>{p.name}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </>
            )}

            <View style={m.modalActions}>
              <TouchableOpacity style={m.cancelBtn} onPress={() => { setWicketModal(false); setWicketType(null); setIsWicket(false); }}>
                <Text style={m.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[m.confirmBtn, !wicketType && m.confirmBtnDisabled]}
                onPress={() => wicketType && setWicketModal(false)}
                disabled={!wicketType}
              >
                <Text style={m.confirmBtnText}>Confirm Wicket</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* ── NEW BATSMAN MODAL ── */}
      <Modal visible={showNewBatsman} transparent animationType="slide">
        <View style={m.overlay}>
          <View style={m.sheet}>
            <Text style={m.sheetTitle}>Select Next Batsman</Text>
            <Text style={m.sheetSub}>Wicket fell. Choose the incoming batsman.</Text>
            {battingXI
              .filter(p => {
                const dismissed = allDeliveries.filter(d => d.isWicket).map(d => d.dismissedId);
                return !dismissed.includes(p.id) && p.id !== strikerId && p.id !== nonStrikerId;
              })
              .map(p => (
                <TouchableOpacity
                  key={p.id}
                  style={m.playerBtn}
                  onPress={() => {
                    setStriker(p.id); // new batsman comes to striker end
                    setNewBatsman(false);
                  }}
                >
                  <Text style={m.playerBtnText}>
                    #{p.jerseyNumber} {p.name}  <Text style={{ color: T.colors.textMuted }}>· {p.primaryRole}</Text>
                  </Text>
                </TouchableOpacity>
              ))
            }
          </View>
        </View>
      </Modal>

      {/* ── NEW BOWLER MODAL ── */}
      <Modal visible={showNewBowler} transparent animationType="slide">
        <View style={m.overlay}>
          <View style={m.sheet}>
            <Text style={m.sheetTitle}>Select Next Bowler</Text>
            <Text style={m.sheetSub}>Over complete. Choose the next bowler.</Text>
            {bowlingXI.filter(p => p.bowlingStyle !== 'none' && p.id !== bowlerId).map(p => (
              <TouchableOpacity
                key={p.id}
                style={m.playerBtn}
                onPress={() => {
                  setBowler(p.id);
                  setNewBowler(false);
                  // Rotate strike at start of new over
                  setStriker(nonStrikerId);
                  setNonStriker(strikerId);
                }}
              >
                <Text style={m.playerBtnText}>
                  {p.name}  <Text style={{ color: T.colors.textMuted }}>· {p.bowlingStyle}</Text>
                </Text>
                <Text style={m.bowlerStats}>
                  {getBowlerStats(p.id).overs} ov · {getBowlerStats(p.id).wickets}/{getBowlerStats(p.id).runs}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </Modal>

      {/* ── UNDO REASON MODAL ── */}
      <Modal visible={showUndoModal} transparent animationType="fade">
        <View style={m.overlay}>
          <View style={m.sheet}>
            <Text style={m.sheetTitle}>Undo Previous Over</Text>
            <Text style={m.sheetSub}>This ball is from a previous over. Please provide a reason.</Text>
            <TextInput
              style={m.reasonInput}
              value={undoReason}
              onChangeText={setUndoReason}
              placeholder="Reason for correction..."
              placeholderTextColor={T.colors.textMuted}
              multiline
            />
            <View style={m.modalActions}>
              <TouchableOpacity style={m.cancelBtn} onPress={() => setUndoModal(false)}>
                <Text style={m.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[m.confirmBtn, !undoReason.trim() && m.confirmBtnDisabled]}
                onPress={() => undoReason.trim() && performUndo()}
                disabled={!undoReason.trim()}
              >
                <Text style={m.confirmBtnText}>Undo Delivery</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

    </View>
  );
};

// ── Styles ───────────────────────────────────────────────────────────────────
const s = StyleSheet.create({
  screen:              { flex: 1, backgroundColor: T.colors.bg },
  center:              { flex: 1, alignItems: 'center', justifyContent: 'center' },
  noMatchText:         { color: T.colors.textMuted, fontSize: 16 },
  backLink:            { marginTop: 16 },
  backLinkText:        { color: T.colors.gold, fontSize: 15, fontWeight: '700' },

  // Scoreboard
  scoreboard:          { backgroundColor: T.colors.bgCard, borderBottomWidth: 1, borderBottomColor: T.colors.border },
  freeHitBanner:       { backgroundColor: T.colors.emeraldDim, padding: 8, alignItems: 'center' },
  freeHitText:         { fontSize: 11, fontWeight: '800', color: T.colors.emerald, letterSpacing: 1 },
  ppBanner:            { backgroundColor: T.colors.goldDim, padding: 7, alignItems: 'center' },
  ppText:              { fontSize: 10, fontWeight: '800', color: T.colors.goldLight, letterSpacing: 1 },
  scoreMain:           { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', padding: 16 },
  scoreLeft:           {},
  teamNameScore:       { fontSize: 11, fontWeight: '700', color: T.colors.textMuted, letterSpacing: 1, marginBottom: 4 },
  scoreRuns:           { fontSize: 52, fontWeight: '900', color: T.colors.text, lineHeight: 56 },
  scoreWickets:        { fontSize: 30, color: T.colors.textMuted },
  scoreOvers:          { fontSize: 13, color: T.colors.textMuted, marginTop: 4 },
  targetBlock:         { alignItems: 'flex-end', backgroundColor: T.colors.bgElevated, padding: 12, borderRadius: T.radius.lg },
  targetLabel:         { fontSize: 9, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 1.5 },
  targetValue:         { fontSize: 28, fontWeight: '900', color: T.colors.goldLight },
  targetNeed:          { fontSize: 10, color: T.colors.textMuted, marginTop: 2, textAlign: 'right' },
  rrr:                 { fontSize: 12, fontWeight: '700', color: T.colors.red, marginTop: 2 },
  dotRow:              { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 14, gap: 8 },
  dot:                 { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  dotLabel:            { fontSize: 11, fontWeight: '800', color: T.colors.bg },
  overLabel:           { fontSize: 11, color: T.colors.textMuted, marginLeft: 6, fontWeight: '600' },

  // Batsmen
  batsmenRow:          { flexDirection: 'row', gap: 10, paddingHorizontal: 12, paddingVertical: 10 },
  batsmanCard:         { flex: 1, backgroundColor: T.colors.bgCard, borderRadius: T.radius.lg, padding: 12, borderWidth: 1, borderColor: T.colors.border, position: 'relative' },
  batsmanCardStriker:  { borderColor: T.colors.gold + '66', backgroundColor: T.colors.goldBg },
  strikerStar:         { position: 'absolute', top: 8, right: 8 },
  strikerStarText:     { fontSize: 12, color: T.colors.gold },
  batsmanRole:         { fontSize: 8, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 1.5, marginBottom: 4 },
  batsmanName:         { fontSize: 13, fontWeight: '700', color: T.colors.text, marginBottom: 4 },
  batsmanScore:        { fontSize: 22, fontWeight: '900', color: T.colors.goldLight },
  batsmanBalls:        { fontSize: 14, color: T.colors.textMuted, fontWeight: '400' },
  batsmanExtra:        { fontSize: 10, color: T.colors.textMuted, marginTop: 2 },

  // Bowler
  bowlerRow:           { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 8, paddingTop: 2 },
  bowlerLeft:          {},
  bowlerLabel:         { fontSize: 8, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 1.5 },
  bowlerName:          { fontSize: 14, fontWeight: '700', color: T.colors.text },
  bowlerFigures:       { fontSize: 12, color: T.colors.textMuted, fontWeight: '500' },

  // Input Panel
  panel:               { marginHorizontal: 12, marginBottom: 8, backgroundColor: T.colors.bgCard, borderRadius: T.radius.xl, padding: 16, borderWidth: 1, borderColor: T.colors.border, ...T.shadow.md },
  panelSection:        { fontSize: 9, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 2, marginBottom: 10, marginTop: 4 },
  runGrid:             { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 },
  runBtn:              { width: 50, height: 50, borderRadius: 25, backgroundColor: T.colors.bgElevated, borderWidth: 2, borderColor: T.colors.border, alignItems: 'center', justifyContent: 'center' },
  runBtnSelected:      { backgroundColor: T.colors.blue, borderColor: T.colors.blue },
  runBtn4:             { borderColor: T.colors.score.four + '88' },
  runBtn6:             { borderColor: T.colors.score.six + '88' },
  runBtn4Active:       { backgroundColor: T.colors.score.four, borderColor: T.colors.score.four },
  runBtn6Active:       { backgroundColor: T.colors.score.six, borderColor: T.colors.score.six },
  runBtnText:          { fontSize: 18, fontWeight: '800', color: T.colors.textSub },
  runBtnTextActive:    { color: '#fff' },
  extrasGrid:          { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  extraBtn:            { paddingHorizontal: 14, paddingVertical: 9, borderRadius: T.radius.full, borderWidth: 1.5, borderColor: T.colors.border, backgroundColor: T.colors.bgElevated },
  extraBtnActive:      { borderColor: T.colors.orange, backgroundColor: T.colors.orangeBg },
  extraBtnText:        { fontSize: 13, fontWeight: '600', color: T.colors.textMuted },
  extraBtnTextActive:  { color: T.colors.orange },
  extraRunsRow:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, paddingVertical: 8, borderTopWidth: 1, borderTopColor: T.colors.borderLight },
  extraRunsLabel:      { fontSize: 11, color: T.colors.textMuted },
  extraRunsBtns:       { flexDirection: 'row', gap: 6 },
  extraRunBtn:         { width: 36, height: 36, borderRadius: 18, backgroundColor: T.colors.bgElevated, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: T.colors.border },
  extraRunBtnActive:   { backgroundColor: T.colors.orange, borderColor: T.colors.orange },
  extraRunBtnText:     { fontSize: 13, fontWeight: '700', color: T.colors.textMuted },
  extraRunBtnTextActive:{ color: '#fff' },
  wicketToggle:        { padding: 13, borderRadius: T.radius.md, borderWidth: 1.5, borderColor: T.colors.border, alignItems: 'center', marginBottom: 12, flexDirection: 'row', justifyContent: 'center', gap: 8 },
  wicketToggleActive:  { borderColor: T.colors.red, backgroundColor: T.colors.redBg },
  wicketToggleText:    { fontSize: 14, fontWeight: '700', color: T.colors.textMuted },
  wicketToggleTextActive:{ color: T.colors.red },
  freeHitNote:         { padding: 10, borderRadius: T.radius.md, backgroundColor: T.colors.emeraldBg, marginBottom: 10 },
  freeHitNoteText:     { fontSize: 11, color: T.colors.emerald, textAlign: 'center' },
  deliverBtn:          { backgroundColor: T.colors.gold, padding: 18, borderRadius: T.radius.lg, alignItems: 'center', ...T.shadow.gold },
  deliverBtnDisabled:  { backgroundColor: T.colors.bgElevated, shadowOpacity: 0 },
  deliverBtnText:      { color: T.colors.bg, fontSize: 15, fontWeight: '800', letterSpacing: 0.5 },

  // Actions bar
  actionsBar:          { flexDirection: 'row', gap: 8, paddingHorizontal: 12, paddingBottom: 8 },
  actionChip:          { paddingHorizontal: 14, paddingVertical: 8, borderRadius: T.radius.full, backgroundColor: T.colors.bgElevated, borderWidth: 1, borderColor: T.colors.border },
  actionChipText:      { fontSize: 12, fontWeight: '600', color: T.colors.textMuted },

  // Ball by ball
  bbbWrap:             { marginHorizontal: 12, marginBottom: 24, backgroundColor: T.colors.bgCard, borderRadius: T.radius.lg, padding: 12, borderWidth: 1, borderColor: T.colors.border },
  bbbTitle:            { fontSize: 10, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 2, marginBottom: 10 },
  bbbRow:              { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: T.colors.borderLight, gap: 10 },
  bbbDot:              { width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  bbbDotText:          { fontSize: 10, fontWeight: '800', color: T.colors.bg },
  bbbInfo:             { width: 80 },
  bbbOver:             { fontSize: 10, fontWeight: '700', color: T.colors.textMuted },
  bbbPlayers:          { fontSize: 10, color: T.colors.textMuted },
  bbbComm:             { flex: 1, fontSize: 11, color: T.colors.textSub },
});

const m = StyleSheet.create({
  overlay:             { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  sheet:               { backgroundColor: T.colors.bgCard, borderTopLeftRadius: T.radius.xxl, borderTopRightRadius: T.radius.xxl, padding: 24, paddingBottom: 40, borderWidth: 1, borderColor: T.colors.border, maxHeight: '80%' },
  sheetTitle:          { fontSize: 18, fontWeight: '800', color: T.colors.text, marginBottom: 4 },
  sheetSub:            { fontSize: 12, color: T.colors.textMuted, marginBottom: 20 },
  freeHitWarn:         { backgroundColor: T.colors.emeraldBg, padding: 10, borderRadius: T.radius.md, marginBottom: 16 },
  freeHitWarnText:     { fontSize: 11, color: T.colors.emerald, textAlign: 'center' },
  wicketGrid:          { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  wicketBtn:           { paddingHorizontal: 14, paddingVertical: 9, borderRadius: T.radius.md, borderWidth: 1.5, borderColor: T.colors.border, backgroundColor: T.colors.bgElevated },
  wicketBtnActive:     { borderColor: T.colors.red, backgroundColor: T.colors.redBg },
  wicketBtnDisabled:   { opacity: 0.3 },
  wicketBtnText:       { fontSize: 12, fontWeight: '700', color: T.colors.textMuted },
  wicketBtnTextActive: { color: T.colors.red },
  wicketInvalidText:   { fontSize: 9, color: T.colors.textMuted, marginTop: 2 },
  subLabel:            { fontSize: 10, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 1.5, marginBottom: 10 },
  playerBtn:           { padding: 14, borderRadius: T.radius.md, borderWidth: 1, borderColor: T.colors.border, backgroundColor: T.colors.bgElevated, marginBottom: 8 },
  playerBtnActive:     { borderColor: T.colors.gold, backgroundColor: T.colors.goldBg },
  playerBtnText:       { fontSize: 14, fontWeight: '600', color: T.colors.text },
  bowlerStats:         { fontSize: 11, color: T.colors.textMuted, marginTop: 3 },
  modalActions:        { flexDirection: 'row', gap: 10, marginTop: 20 },
  cancelBtn:           { flex: 1, padding: 14, borderRadius: T.radius.lg, borderWidth: 1, borderColor: T.colors.border, alignItems: 'center' },
  cancelBtnText:       { fontSize: 14, fontWeight: '700', color: T.colors.textSub },
  confirmBtn:          { flex: 2, padding: 14, borderRadius: T.radius.lg, backgroundColor: T.colors.red, alignItems: 'center' },
  confirmBtnDisabled:  { backgroundColor: T.colors.bgElevated },
  confirmBtnText:      { fontSize: 14, fontWeight: '800', color: T.colors.bg },
  reasonInput:         { backgroundColor: T.colors.bgElevated, borderRadius: T.radius.md, borderWidth: 1, borderColor: T.colors.border, color: T.colors.text, padding: 14, fontSize: 14, minHeight: 80, textAlignVertical: 'top' },
  xxl:                 28,
});
