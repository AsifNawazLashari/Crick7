// Cricket A7 — Toss Screen | Asif Lashari | A7 Studio
// Happens AFTER scorer activates via token
// Determines batting/bowling order → creates innings record → goes to opener selection
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  StatusBar, Animated, Alert,
} from 'react-native';
import { theme } from '../../theme';
import { db } from '../../data/db';

const T = theme;
interface Props { matchId: string; onComplete: (matchId: string) => void; onBack: () => void; }

export const TossScreen: React.FC<Props> = ({ matchId, onComplete, onBack }) => {
  const match = db.matches.getById(matchId)!;
  const team1 = db.teams.getById(match.team1Id)!;
  const team2 = db.teams.getById(match.team2Id)!;
  const tournament = match.tournamentId ? db.tournaments.getById(match.tournamentId) : null;

  const [tossWinner, setTossWinner] = useState<string | null>(null);
  const [elected, setElected]       = useState<'bat' | 'bowl' | null>(null);
  const [confirming, setConfirming] = useState(false);

  const battingTeamId = tossWinner
    ? (elected === 'bat' ? tossWinner : (tossWinner === team1.id ? team2.id : team1.id))
    : null;
  const bowlingTeamId = battingTeamId
    ? (battingTeamId === team1.id ? team2.id : team1.id)
    : null;

  const battingTeam = battingTeamId ? db.teams.getById(battingTeamId) : null;
  const bowlingTeam = bowlingTeamId ? db.teams.getById(bowlingTeamId) : null;

  const canConfirm = tossWinner && elected;

  const handleConfirm = async () => {
    if (!canConfirm || !battingTeamId || !bowlingTeamId) return;
    setConfirming(true);

    await new Promise(r => setTimeout(r, 400));

    // Update match
    db.matches.update(matchId, {
      tossWonBy: tossWinner,
      electedTo: elected,
      status: 'openers_pending',
      currentInningsIndex: 0,
    });

    // Create innings 1
    db.innings.create({
      matchId,
      inningsNumber: 1,
      battingTeamId,
      bowlingTeamId,
      totalRuns: 0,
      wickets: 0,
      legalBalls: 0,
      extras: { wides: 0, noBalls: 0, byes: 0, legByes: 0, penalty: 0 },
      target: null,
      status: 'pending',
      isSuperOver: false,
      maxWickets: 10,
    });

    setConfirming(false);
    onComplete(matchId);
  };

  return (
    <View style={s.screen}>
      <StatusBar barStyle="light-content" />

      <View style={s.header}>
        <TouchableOpacity onPress={onBack} style={s.backBtn}>
          <Text style={s.backText}>‹</Text>
        </TouchableOpacity>
        <View style={s.headerCenter}>
          <Text style={s.headerTitle}>Toss</Text>
          {tournament && <Text style={s.headerSub}>{tournament.name}</Text>}
        </View>
        <View style={{ width: 40 }} />
      </View>

      <View style={s.content}>

        {/* Match banner */}
        <View style={s.matchBanner}>
          <View style={s.bannerTeam}>
            <View style={[s.teamColorCircle, { backgroundColor: team1.color }]} />
            <Text style={s.bannerTeamName}>{team1.name}</Text>
          </View>
          <View style={s.bannerCenter}>
            <Text style={s.vsLabel}>VS</Text>
            <Text style={s.venueText} numberOfLines={1}>📍 {match.venue}</Text>
          </View>
          <View style={[s.bannerTeam, s.bannerTeamRight]}>
            <Text style={[s.bannerTeamName, { textAlign: 'right' }]}>{team2.name}</Text>
            <View style={[s.teamColorCircle, { backgroundColor: team2.color }]} />
          </View>
        </View>

        {/* Step 1: Who won the toss */}
        <Text style={s.stepLabel}>WHO WON THE TOSS?</Text>
        <View style={s.tossRow}>
          {[team1, team2].map(team => (
            <TouchableOpacity
              key={team.id}
              style={[s.tossCard, tossWinner === team.id && s.tossCardActive]}
              onPress={() => { setTossWinner(team.id); setElected(null); }}
              activeOpacity={0.75}
            >
              <View style={[s.tossColorBar, { backgroundColor: team.color }]} />
              <Text style={[s.tossTeamName, tossWinner === team.id && s.tossTeamNameActive]}>
                {team.name}
              </Text>
              {tossWinner === team.id && (
                <View style={s.tossCheck}>
                  <Text style={s.tossCheckText}>✓</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* Step 2: Bat or Bowl */}
        {tossWinner && (
          <>
            <Text style={s.stepLabel}>
              {tossWinner === team1.id ? team1.name : team2.name} ELECTS TO
            </Text>
            <View style={s.electionRow}>
              <TouchableOpacity
                style={[s.electionCard, elected === 'bat' && s.electionCardActive]}
                onPress={() => setElected('bat')}
                activeOpacity={0.75}
              >
                <Text style={s.electionIcon}>🏏</Text>
                <Text style={[s.electionLabel, elected === 'bat' && s.electionLabelActive]}>BAT</Text>
                <Text style={s.electionDesc}>Bat first, set a target</Text>
                {elected === 'bat' && <View style={s.electionCheck}><Text style={s.tossCheckText}>✓</Text></View>}
              </TouchableOpacity>
              <TouchableOpacity
                style={[s.electionCard, elected === 'bowl' && s.electionCardActive]}
                onPress={() => setElected('bowl')}
                activeOpacity={0.75}
              >
                <Text style={s.electionIcon}>⚾</Text>
                <Text style={[s.electionLabel, elected === 'bowl' && s.electionLabelActive]}>BOWL</Text>
                <Text style={s.electionDesc}>Bowl first, chase target</Text>
                {elected === 'bowl' && <View style={s.electionCheck}><Text style={s.tossCheckText}>✓</Text></View>}
              </TouchableOpacity>
            </View>
          </>
        )}

        {/* Summary */}
        {battingTeam && bowlingTeam && (
          <View style={s.summaryCard}>
            <Text style={s.summaryTitle}>MATCH SUMMARY</Text>
            <View style={s.summaryRow}>
              <View style={s.summaryBlock}>
                <Text style={s.summaryRole}>BATTING FIRST</Text>
                <View style={[s.summaryDot, { backgroundColor: battingTeam.color }]} />
                <Text style={s.summaryTeam}>{battingTeam.name}</Text>
              </View>
              <Text style={s.summaryArrow}>→</Text>
              <View style={[s.summaryBlock, { alignItems: 'flex-end' }]}>
                <Text style={s.summaryRole}>BOWLING FIRST</Text>
                <View style={[s.summaryDot, { backgroundColor: bowlingTeam.color }]} />
                <Text style={s.summaryTeam}>{bowlingTeam.name}</Text>
              </View>
            </View>
          </View>
        )}

        <View style={{ flex: 1 }} />

        {/* Confirm button */}
        <TouchableOpacity
          style={[s.confirmBtn, (!canConfirm || confirming) && s.confirmBtnDisabled]}
          onPress={handleConfirm}
          disabled={!canConfirm || confirming}
          activeOpacity={0.85}
        >
          <Text style={s.confirmBtnText}>
            {confirming ? 'Setting Up Match...' : 'Confirm Toss & Select Openers →'}
          </Text>
        </TouchableOpacity>

      </View>
    </View>
  );
};

const s = StyleSheet.create({
  screen:              { flex: 1, backgroundColor: T.colors.bg },
  header:              { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: T.colors.border },
  backBtn:             { width: 40 },
  backText:            { fontSize: 22, color: T.colors.gold, fontWeight: '600' },
  headerCenter:        { flex: 1, alignItems: 'center' },
  headerTitle:         { fontSize: 18, fontWeight: '800', color: T.colors.text },
  headerSub:           { fontSize: 11, color: T.colors.textMuted, marginTop: 2 },
  content:             { flex: 1, padding: 20 },
  matchBanner:         { flexDirection: 'row', alignItems: 'center', backgroundColor: T.colors.bgCard, borderRadius: T.radius.xl, padding: 16, marginBottom: 28, borderWidth: 1, borderColor: T.colors.border, ...T.shadow.md },
  bannerTeam:          { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
  bannerTeamRight:     { justifyContent: 'flex-end' },
  teamColorCircle:     { width: 12, height: 12, borderRadius: 6 },
  bannerTeamName:      { fontSize: 13, fontWeight: '700', color: T.colors.text, flex: 1 },
  bannerCenter:        { alignItems: 'center', paddingHorizontal: 10 },
  vsLabel:             { fontSize: 14, fontWeight: '900', color: T.colors.textMuted },
  venueText:           { fontSize: 9, color: T.colors.textMuted, marginTop: 4, textAlign: 'center', maxWidth: 80 },
  stepLabel:           { fontSize: 10, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 2, marginBottom: 14 },
  tossRow:             { flexDirection: 'row', gap: 12, marginBottom: 28 },
  tossCard:            { flex: 1, backgroundColor: T.colors.bgCard, borderRadius: T.radius.lg, padding: 18, borderWidth: 2, borderColor: T.colors.border, alignItems: 'center', position: 'relative' },
  tossCardActive:      { borderColor: T.colors.gold, backgroundColor: T.colors.goldBg, ...T.shadow.gold },
  tossColorBar:        { width: 32, height: 4, borderRadius: 2, marginBottom: 10 },
  tossTeamName:        { fontSize: 14, fontWeight: '700', color: T.colors.textSub, textAlign: 'center' },
  tossTeamNameActive:  { color: T.colors.goldLight },
  tossCheck:           { position: 'absolute', top: 8, right: 8, width: 22, height: 22, borderRadius: 11, backgroundColor: T.colors.gold, alignItems: 'center', justifyContent: 'center' },
  tossCheckText:       { fontSize: 12, color: T.colors.bg, fontWeight: '800' },
  electionRow:         { flexDirection: 'row', gap: 12, marginBottom: 24 },
  electionCard:        { flex: 1, backgroundColor: T.colors.bgCard, borderRadius: T.radius.lg, padding: 20, borderWidth: 2, borderColor: T.colors.border, alignItems: 'center', position: 'relative' },
  electionCardActive:  { borderColor: T.colors.emerald, backgroundColor: T.colors.emeraldBg, ...T.shadow.md },
  electionIcon:        { fontSize: 30, marginBottom: 8 },
  electionLabel:       { fontSize: 18, fontWeight: '900', color: T.colors.textSub, letterSpacing: 2 },
  electionLabelActive: { color: T.colors.emerald },
  electionDesc:        { fontSize: 11, color: T.colors.textMuted, marginTop: 4, textAlign: 'center' },
  electionCheck:       { position: 'absolute', top: 8, right: 8, width: 22, height: 22, borderRadius: 11, backgroundColor: T.colors.emerald, alignItems: 'center', justifyContent: 'center' },
  summaryCard:         { backgroundColor: T.colors.bgElevated, borderRadius: T.radius.lg, padding: 16, borderWidth: 1, borderColor: T.colors.border, marginBottom: 20 },
  summaryTitle:        { fontSize: 9, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 2, textAlign: 'center', marginBottom: 14 },
  summaryRow:          { flexDirection: 'row', alignItems: 'center' },
  summaryBlock:        { flex: 1, alignItems: 'flex-start' },
  summaryRole:         { fontSize: 9, fontWeight: '800', color: T.colors.textMuted, letterSpacing: 1.5, marginBottom: 6 },
  summaryDot:          { width: 24, height: 4, borderRadius: 2, marginBottom: 6 },
  summaryTeam:         { fontSize: 14, fontWeight: '700', color: T.colors.text },
  summaryArrow:        { fontSize: 20, color: T.colors.gold, paddingHorizontal: 16 },
  confirmBtn:          { backgroundColor: T.colors.emerald, padding: 18, borderRadius: T.radius.xl, alignItems: 'center', marginBottom: 16, ...T.shadow.md },
  confirmBtnDisabled:  { backgroundColor: T.colors.bgElevated, shadowOpacity: 0 },
  confirmBtnText:      { fontSize: 15, fontWeight: '800', color: T.colors.bg },
});
