// Cricket A7 — Scoring Engine | Core Logic
// Author: Asif Lashari | A7 Studio

import { Delivery, Innings, LiveMatchState, LiveBatsman, LiveBowler, WicketType } from '../types';

/**
 * Determines if a delivery is a legal ball (counts toward the over)
 * Wides and No-Balls are NOT legal deliveries
 */
export function isLegalDelivery(extraType: string | null): boolean {
  return extraType !== 'wide' && extraType !== 'no-ball';
}

/**
 * Determines if a wicket type is valid on a free hit delivery
 * On a free hit: only run-out, obstructing, and hit-wicket are valid
 */
export function isValidDismissalOnFreeHit(wicketType: WicketType): boolean {
  return wicketType === 'run-out' || wicketType === 'obstructing' || wicketType === 'hit-wicket';
}

/**
 * Determines if a wicket is credited to the bowler
 * run-out, obstructing, timed-out, retired-out are NOT bowler wickets
 */
export function isBowlerWicket(wicketType: WicketType): boolean {
  return !['run-out', 'obstructing', 'timed-out', 'retired-out'].includes(wicketType);
}

/**
 * A stumping is valid off a wide (but NOT off a no-ball)
 */
export function isStumpingValid(wicketType: WicketType, extraType: string | null): boolean {
  if (wicketType !== 'stumped') return true;
  if (extraType === 'no-ball') return false; // stumped off no-ball is invalid
  return true; // stumped off wide is valid
}

/**
 * LBW, caught, bowled are NOT valid on a no-ball or free hit
 */
export function isDismissalValidOnDelivery(
  wicketType: WicketType,
  isFreeHit: boolean,
  extraType: string | null
): { valid: boolean; reason?: string } {
  const isNoBall = extraType === 'no-ball';

  if (isFreeHit && !isValidDismissalOnFreeHit(wicketType)) {
    return { valid: false, reason: `${wicketType} is not valid on a Free Hit. Only run-out, obstructing, or hit-wicket.` };
  }

  if (isNoBall && ['lbw', 'caught', 'bowled'].includes(wicketType)) {
    return { valid: false, reason: `${wicketType} cannot occur off a No Ball.` };
  }

  if (!isStumpingValid(wicketType, extraType)) {
    return { valid: false, reason: `Stumped cannot occur off a No Ball.` };
  }

  return { valid: true };
}

/**
 * After a no-ball, the next delivery is a free hit
 * After a free-hit no-ball, the next is ALSO a free hit
 */
export function computeNextIsFreeHit(extraType: string | null): boolean {
  return extraType === 'no-ball';
}

/**
 * Total runs from a delivery (runs off bat + extra penalty runs)
 * Wide = 1 penalty + any runs taken
 * No-Ball = 1 penalty + runs off bat
 * Bye/LegBye = runs taken but NOT credited to batsman
 */
export function computeTotalRunsFromDelivery(
  runsOffBat: number,
  extraType: string | null,
  extraRuns: number
): number {
  let total = runsOffBat;
  if (extraType === 'wide' || extraType === 'no-ball') total += 1; // 1 penalty run
  if (extraType === 'bye' || extraType === 'leg-bye') total += extraRuns;
  if (extraType === 'penalty') total += extraRuns;
  return total;
}

/**
 * Check if powerplay is active given current over and tournament powerplay config
 */
export function getActivePowerplay(
  overNumber: number,
  powerplays: { label: string; fromOver: number; toOver: number }[]
): { active: boolean; label: string | null } {
  for (const pp of powerplays) {
    if (overNumber >= pp.fromOver && overNumber <= pp.toOver) {
      return { active: true, label: pp.label };
    }
  }
  return { active: false, label: null };
}

/**
 * Format overs display: 34 legal balls = "5.4"
 */
export function formatOvers(legalBalls: number): string {
  const overs = Math.floor(legalBalls / 6);
  const balls = legalBalls % 6;
  return `${overs}.${balls}`;
}

/**
 * Current run rate
 */
export function computeCRR(runs: number, legalBalls: number): string {
  if (legalBalls === 0) return '0.00';
  const overs = legalBalls / 6;
  return (runs / overs).toFixed(2);
}

/**
 * Required run rate for chasing team
 */
export function computeRRR(target: number, currentRuns: number, totalOvers: number, legalBallsBowled: number): string {
  const runsNeeded = target - currentRuns;
  if (runsNeeded <= 0) return '0.00';
  const ballsRemaining = (totalOvers * 6) - legalBallsBowled;
  if (ballsRemaining <= 0) return '∞';
  return ((runsNeeded / ballsRemaining) * 6).toFixed(2);
}

/**
 * Check if innings should end
 */
export function shouldInningsEnd(
  wickets: number,
  legalBalls: number,
  totalOvers: number,
  maxWickets: number,
  currentRuns: number,
  target: number | null
): { end: boolean; reason: string | null } {
  if (wickets >= maxWickets) return { end: true, reason: 'All out' };
  if (legalBalls >= totalOvers * 6) return { end: true, reason: 'Overs complete' };
  if (target !== null && currentRuns >= target) return { end: true, reason: 'Target achieved' };
  return { end: false, reason: null };
}

/**
 * Determine match result text
 */
export function computeResult(
  innings1: { teamId: string; runs: number; wickets: number },
  innings2: { teamId: string; runs: number; wickets: number },
  team1Name: string,
  team2Name: string
): string {
  if (innings2.runs > innings1.runs) {
    const wicketsLeft = 10 - innings2.wickets;
    return `${innings2.teamId === innings1.teamId ? team1Name : team2Name} won by ${wicketsLeft} wicket${wicketsLeft !== 1 ? 's' : ''}`;
  } else if (innings1.runs > innings2.runs) {
    const margin = innings1.runs - innings2.runs;
    return `${innings1.teamId === innings1.teamId ? team1Name : team2Name} won by ${margin} run${margin !== 1 ? 's' : ''}`;
  } else {
    return 'Match tied';
  }
}

/**
 * Generate alphanumeric scorer token (8 chars)
 * No need for nanoid dependency — simple crypto-quality generation
 */
export function generateScorerToken(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // removed confusable chars O,0,I,1
  let token = '';
  for (let i = 0; i < 8; i++) {
    token += chars[Math.floor(Math.random() * chars.length)];
  }
  return `A7-${token}`;
}

/**
 * Commentary variation bank
 */
const COMMENTARY_BANK = {
  dot: [
    'Dot ball. Tight line, batsman defends solidly.',
    'Good length delivery, no run taken.',
    'Excellent discipline from the bowler. Dot ball.',
    'Nothing doing off that delivery. Watchful defence.',
    'Bowler wins this battle. No run.',
  ],
  single: [
    'Worked away for a single.',
    'Nudged into the gap, one run taken.',
    'Quick single. Good running between the wickets.',
    'Rotates the strike with a deft touch.',
  ],
  double: [
    'Good running! Two taken.',
    'Pushed into the outfield, they come back for two.',
    'Quick between the wickets — two runs.',
  ],
  triple: ['Excellent running! Three completed.', 'They push hard, three runs scored.'],
  four: [
    'FOUR! Cracking shot, finds the boundary!',
    'FOUR! Beautifully timed through the covers.',
    'FOUR! No stopping that. Raced to the fence.',
    'FOUR! Punched hard, splits the field perfectly.',
    'FOUR! Driven with authority to the boundary!',
  ],
  six: [
    'SIX! Massive! Clears the boundary with ease!',
    'SIX! Launches it high and straight over the bowler!',
    'SIX! Pure power! Into the stands!',
    'SIX! Whipped off the legs, sails over midwicket!',
    'SIX! Takes on the short ball and deposits it out of the ground!',
  ],
  wide: [
    'Wide! Strays too far down leg, umpire signals.',
    'Wide ball. Drifts outside the tramlines.',
    'Wayward delivery, called wide by the umpire.',
  ],
  noBall: [
    'No Ball! Overstepped the crease. Free hit coming!',
    'No ball! The front foot is over the line. FREE HIT!',
    'No Ball called! The fielding side pay the price.',
  ],
  freeHit: [
    'FREE HIT! The batsman can only be dismissed by run-out!',
    'FREE HIT delivery — go hard!',
  ],
  wicketBowled: ['BOWLED! Crashes into the stumps. What a delivery!', 'BOWLED! The stumps are shattered!', 'BOWLED! Went through the gate!'],
  wicketCaught: ['CAUGHT! Sharp catch taken!', 'OUT! Feathered to the keeper — caught!', 'CAUGHT! Brilliant take in the deep!'],
  wicketLBW: ['OUT LBW! Plumb in front, finger goes up!', 'LBW! Slid in and hit him on the pad. Out!'],
  wicketRunOut: ['RUN OUT! Direct hit! Caught miles short!', 'RUN OUT! What a throw from the outfield!'],
  wicketStumped: ['STUMPED! Drifted out of the crease, keeper does the rest!', 'STUMPED! Quick as lightning behind the stumps!'],
  wicketHitWicket: ['HIT WICKET! Unbelievable! Hit his own stumps!'],
};

export function getCommentary(
  deliveryData: {
    runsOffBat: number;
    extraType: string | null;
    isWicket: boolean;
    wicketType: WicketType | null;
    isFreeHit: boolean;
    batsmanName: string;
    bowlerName: string;
  }
): string {
  const { runsOffBat, extraType, isWicket, wicketType, isFreeHit, batsmanName, bowlerName } = deliveryData;

  if (extraType === 'wide') {
    return pick(COMMENTARY_BANK.wide);
  }
  if (extraType === 'no-ball') {
    return pick(COMMENTARY_BANK.noBall);
  }
  if (isFreeHit && !isWicket) {
    const base = runsOffBat === 6 ? pick(COMMENTARY_BANK.six) : runsOffBat === 4 ? pick(COMMENTARY_BANK.four) : `${runsOffBat} off the free hit.`;
    return `FREE HIT! ${base}`;
  }
  if (isWicket) {
    switch (wicketType) {
      case 'bowled': return `${pick(COMMENTARY_BANK.wicketBowled)} ${batsmanName} departs.`;
      case 'caught': return `${pick(COMMENTARY_BANK.wicketCaught)} ${batsmanName} is out.`;
      case 'lbw': return `${pick(COMMENTARY_BANK.wicketLBW)} ${batsmanName} has to go.`;
      case 'run-out': return `${pick(COMMENTARY_BANK.wicketRunOut)} ${batsmanName} is gone.`;
      case 'stumped': return `${pick(COMMENTARY_BANK.wicketStumped)} ${batsmanName} out.`;
      case 'hit-wicket': return `${pick(COMMENTARY_BANK.wicketHitWicket)} Poor ${batsmanName}.`;
      default: return `OUT! ${batsmanName} dismissed — ${wicketType}.`;
    }
  }
  switch (runsOffBat) {
    case 0: return pick(COMMENTARY_BANK.dot);
    case 1: return pick(COMMENTARY_BANK.single);
    case 2: return pick(COMMENTARY_BANK.double);
    case 3: return pick(COMMENTARY_BANK.triple);
    case 4: return pick(COMMENTARY_BANK.four);
    case 6: return pick(COMMENTARY_BANK.six);
    default: return `${runsOffBat} runs scored.`;
  }
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}
